﻿'Class for the Employees table
'Programmer:        Nhuan Thi
'Date:              11/30/2011
'Project:           Final Project Milestone 2

Public Class EmployeesClass
    'Variables
    Private EmployeeIdInteger As Integer
    Private FirstNameString As String
    Private LastNameString As String
    'Empty constructor
    Public Sub New()

    End Sub
    'Full constructor with all variables
    Public Sub New(ByVal _EmployeeIDInteger As Integer, ByVal _FirstNameString As String, _
                   ByVal _LastNameString As String)
        With Me
            .EmployeeIdInteger = _EmployeeIDInteger
            .FirstNameString = _FirstNameString
            .LastNameString = _LastNameString
        End With
    End Sub
    'Methods
    Public ReadOnly Property EmployeeID() As Integer
        Get
            Return Me.EmployeeIdInteger
        End Get
    End Property

    Public Property FirstName As String
        Get
            Return Me.FirstNameString
        End Get
        Set(ByVal value As String)
            Me.FirstNameString = value
        End Set
    End Property

    Public Property LastName As String
        Get
            Return Me.LastNameString
        End Get
        Set(ByVal value As String)
            Me.LastNameString = value
        End Set
    End Property
    'ToString function
    Public Overrides Function ToString() As String
        Dim EmployeeInfoString As String = "Employee ID: " & Me.EmployeeIdInteger & "," & _
                                            "First name: " & Me.FirstNameString & "," & _
                                            "Last name: " & Me.LastNameString & "."
        Return EmployeeInfoString
    End Function
End Class
