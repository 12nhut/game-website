﻿'Programmer:        Nhuan Thi
'Date:              11/30/2011
'Project:           Final Project Milestone 2

Public Class LocationClass
    Private StoreIDInteger As Integer
    Private AddressString As String
    Private CityString As String
    Private StateString As String
    Private ZipCodeString As String
    Private PhoneString As String

    Public Sub New()

    End Sub

    Public Sub New(ByVal _StoreIDInteger As Integer, ByVal _AddressString As String, ByVal _CityString As String, _
                   ByVal _StateString As String, ByVal _ZipCodeString As String, ByVal _PhoneString As String)
        With Me
            .StoreIDInteger = _StoreIDInteger
            .AddressString = _AddressString
            .CityString = _CityString
            .StateString = _StateString
            .ZipCodeString = _ZipCodeString
            .PhoneString = _PhoneString
        End With
    End Sub

    Public ReadOnly Property StoreID() As Integer
        Get
            Return Me.StoreIDInteger
        End Get
    End Property

    Public Property Address() As String
        Get
            Return Me.AddressString
        End Get
        Set(ByVal value As String)
            Me.AddressString = value
        End Set
    End Property

    Public Property City() As String
        Get
            Return Me.CityString
        End Get
        Set(ByVal value As String)
            Me.CityString = value
        End Set
    End Property

    Public Property State() As String
        Get
            Return Me.StateString
        End Get
        Set(ByVal value As String)
            Me.StateString = value
        End Set
    End Property

    Public Property ZipCode() As String
        Get
            Return Me.ZipCodeString
        End Get
        Set(ByVal value As String)
            Me.ZipCodeString = value
        End Set
    End Property

    Public Property Phone() As String
        Get
            Return Me.PhoneString
        End Get
        Set(ByVal value As String)
            Me.PhoneString = value
        End Set
    End Property


    Public Overrides Function ToString() As String
        Dim LocationInfoString As String = "Store ID: " & Me.StoreIDInteger & "," & _
                                            "Address:" & Me.AddressString & "," & _
                                            "City: " & Me.CityString & "," & _
                                            "State: " & Me.StateString & "," & _
                                            "ZipCode: " & Me.ZipCodeString & "," & _
                                            "Phone: " & Me.PhoneString & "."
        Return LocationInfoString
    End Function
End Class
