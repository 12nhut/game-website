﻿'Programmer:        Kevin Kruse
'Date:              12/07/2011
'Project:           Final Project Milestone 2

Public Class OrderConfirmationForm

    Public AllCustomersList As New List(Of Customer)

    Private Sub OrderConfirmationForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        CustomerNameComboBox.SelectedIndex = 0

        'TODO: This line of code loads data into the 'CompKCCDataSet.Customers' table. You can move, or remove it, as needed.
        Me.CustomersTableAdapter.Fill(Me.CompKCCDataSet.Customers)

        'LINQ query to pull out all the customers from the Database
        Dim AllCustomers = From SingleCustomer As CompKCCDataSet.CustomersRow In CompKCCDataSet.Customers.Rows
                           Order By SingleCustomer.CustomerID Ascending
                             Select SingleCustomer

        'Creates a Customer object for each existing customer and adds it to the list
        For Each SingleCustomer In AllCustomers
            Dim ExistingCustomer As Customer = New Customer(SingleCustomer.CustomerID, SingleCustomer.FullName, _
                                                            SingleCustomer.Address, SingleCustomer.City, SingleCustomer.State, _
                                                            SingleCustomer.ZipCode)
            CustomerNameComboBox.Items.Add(ExistingCustomer.FullName)
            AllCustomersList.Add(ExistingCustomer)
        Next
        EmployeeIDLabel.Text = (MainForm.LoggedInEmployee).ToString
        DateLabel.Text = DateTime.Now.ToString("MM/dd/yyyy")
    End Sub

    Private Sub PlaceOrderButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PlaceOrderButton.Click
        'Create a new invoice
        'LINQ query to pull last OrderID from the invoices
        Dim LastOrderID = From InvoicesOrderID As CompKCCDataSet.InvoicesRow In CompKCCDataSet.Invoices.Rows
                          Select InvoicesOrderID.OrderID

        'Creates new OrderID
        Dim NewOrderIDInteger As Integer = LastOrderID.Max + 1

        'Sort through each categories list and create an object from that list
        If Not IsNothing(PlaceAnOrderForm.ComputersList) Then
            For Each SingleComputer In PlaceAnOrderForm.ComputersList
                'Dim NewComputer As ComputersClass = New ComputersClass(SingleComputer.ProductID, SingleComputer.Brand, _
                '                                                       SingleComputer.Cost, SingleComputer.Model, SingleComputer.Type, _
                '                                                       SingleComputer.Description)
                Dim NewInvoice As InvoicesClass = New InvoicesClass(NewOrderIDInteger, SingleComputer.ProductID)
                CompKCCDataSet.Invoices.Rows.Add(NewInvoice.OrderID.ToString, NewInvoice.ProductID.ToString)
            Next
        End If
    End Sub

    Private Sub CustomerNameComboBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CustomerNameComboBox.SelectedIndexChanged
        If CustomerNameComboBox.SelectedIndex = 0 Then
            Exit Sub
        Else
            Dim CustomerIndex As Integer = CustomerNameComboBox.SelectedIndex - 1
            Dim SelectedCustomer As Customer = AllCustomersList(CustomerIndex)

            CustomerIDLabel.Text = SelectedCustomer.CustomerID
            AddressLabel.Text = SelectedCustomer.Address
            CityLabel.Text = SelectedCustomer.City
            StateLabel.Text = SelectedCustomer.State
            ZipCodeLabel.Text = SelectedCustomer.ZipCode
        End If
    End Sub

    Private Sub NewCustomerButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NewCustomerButton.Click
        'Creates a new customer form and the displays it
        Dim CreateNewCustomerForm As New NewCustomerForm
        CreateNewCustomerForm.ShowDialog()
        'if the newcustomer form returns no tag then exit the sub otherwise 
        'add the new customer object to the list and combobox
        If IsNothing(CreateNewCustomerForm.Tag) Then
            Exit Sub
        Else
            Dim NewCustomer As Customer = CType(CreateNewCustomerForm.Tag, Customer)
            AllCustomersList.Add(NewCustomer)
            CustomerNameComboBox.Items.Add(NewCustomer.FullName)
            CustomerNameComboBox.Refresh()
            CompKCCDataSet.Customers.Rows.Add(CInt(NewCustomer.CustomerID), NewCustomer.Address.ToString, _
                                              NewCustomer.City.ToString, NewCustomer.State.ToString, CInt(NewCustomer.ZipCode), NewCustomer.FullName.ToString)
            Me.Validate()
            Me.CustomersBindingSource.EndEdit()
            Me.TableAdapterManager.UpdateAll(Me.CompKCCDataSet)
        End If
    End Sub
End Class