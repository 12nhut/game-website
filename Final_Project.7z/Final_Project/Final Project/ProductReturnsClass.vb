﻿'Class for the ProductReturns table
'Programmer:        Nhuan Thi
'Date:              11/30/2011
'Project:           Final Project Milestone 2

Public Class ProductReturnsClass
    'Variables
    Private ReturnIdInteger As Integer
    Private EmployeeIDInteger As Integer
    Private ProductIDInteger As Integer
    Private QuantityInteger As Integer
    Private DateReturnedDate As Date
    Private ReasonString As String
    'Empty constructor
    Public Sub New()

    End Sub
    'Full constructor with all variables
    Public Sub New(ByVal _ReturnIDInteger As Integer, ByVal _EmployeeIDInteger As Integer, ByVal _ProductIDInteger As Integer, _
                   ByVal _QuantityInteger As Integer, ByVal _DateReturned As Date, ByVal _ReasonString As String)
        With Me
            .ReturnIdInteger = _ReturnIDInteger
            .EmployeeIDInteger = _EmployeeIDInteger
            .ProductIDInteger = _ProductIDInteger
            .QuantityInteger = _QuantityInteger
            .DateReturnedDate = _DateReturned
            .ReasonString = _ReasonString
        End With
    End Sub
    'Methods
    Public ReadOnly Property ReturnId() As Integer
        Get
            Return Me.ReturnIdInteger
        End Get
    End Property

    Public ReadOnly Property EmployeeID() As Integer
        Get
            Return Me.EmployeeIDInteger
        End Get
    End Property

    Public ReadOnly Property ProductID() As Integer
        Get
            Return Me.ProductIDInteger
        End Get
    End Property

    Public Property Quantity() As Integer
        Get
            Return Me.QuantityInteger
        End Get
        Set(ByVal value As Integer)
            Me.QuantityInteger = value
        End Set
    End Property

    Public Property DateReturned() As Date
        Get
            Return Me.DateReturnedDate
        End Get
        Set(ByVal value As Date)
            Me.DateReturnedDate = value
        End Set
    End Property

    Public Property Reason() As String
        Get
            Return Me.ReasonString
        End Get
        Set(ByVal value As String)
            Me.ReasonString = value
        End Set
    End Property
    'ToString function
    Public Overrides Function ToString() As String
        Dim ProductReturnsInfoString As String = "Return ID: " & Me.ReturnIdInteger & "," & _
                                                "Employee ID: " & Me.EmployeeIDInteger & "," & _
                                                "Product ID: " & Me.ProductIDInteger & "," & _
                                                "Quantity: " & Me.QuantityInteger & "," & _
                                                "Date returned: " & Me.DateReturnedDate & "," & _
                                                "Reason: " & Me.ReasonString & "."
        Return ProductReturnsInfoString
    End Function
End Class
