﻿'Programmer:        Kevin Kruse
'Date:              11/30/2011
'Project:           Final Project Milestone 2

Public Class MonitorClass
    Private ProductIDString As String
    Private BrandString As String
    Private ModelString As String
    Private TypeString As String
    Private SizeDecimal As Decimal
    Private CostDecimal As Decimal

    Public Sub New()
        'Empty constructor
    End Sub

    'Full constructor
    Public Sub New(ByVal _ProductIDString As String, ByVal _BrandString As String, _
                   ByVal _TypeString As String, ByVal _ModelString As String, _
                    ByVal _SizeDecimal As Decimal, ByVal _CostDecimal As Decimal)
        With Me
            .ProductIDString = _ProductIDString
            .BrandString = _BrandString
            .TypeString = _TypeString
            .ModelString = _ModelString
            .SizeDecimal = _SizeDecimal
            .CostDecimal = _CostDecimal
        End With
    End Sub

    Public Property ProductID As String
        Get
            Return Me.ProductIDString
        End Get
        Set(ByVal value As String)
            Me.ProductIDString = value
        End Set
    End Property

    Public Property Brand As String
        Get
            Return Me.BrandString
        End Get
        Set(ByVal value As String)
            Me.BrandString = value
        End Set
    End Property

    Public Property Type As String
        Get
            Return Me.TypeString
        End Get
        Set(ByVal value As String)
            Me.TypeString = value
        End Set
    End Property

    Public Property Size As Decimal
        Get
            Return Me.SizeDecimal
        End Get
        Set(ByVal value As Decimal)
            Me.SizeDecimal = value
        End Set
    End Property

    Public Property Model As String
        Get
            Return Me.ModelString
        End Get
        Set(ByVal value As String)
            Me.ModelString = value
        End Set
    End Property

    Public Property Cost As Decimal
        Get
            Return Me.CostDecimal
        End Get
        Set(ByVal value As Decimal)
            Me.CostDecimal = value
        End Set
    End Property

    Public Overrides Function ToString() As String
        Dim MonitorsString As String = "Product ID: " & ProductIDString & ", " & _
                                        "Brand: " & BrandString & ", " & _
                                        "Model: " & ModelString & ", " & _
                                        "Type: " & TypeString & ", " & _
                                        "Size: " & SizeDecimal & ", " & _
                                        "Cost: " & CostDecimal & "."

        Return MonitorsString
    End Function
End Class
