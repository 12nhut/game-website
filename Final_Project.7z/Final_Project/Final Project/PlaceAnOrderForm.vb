﻿'Programmer:        Kevin Kruse/Nhuan Thi
'Date:              11/30/2011
'Project:           Final Project Milestone 2

Public Class PlaceAnOrderForm
    'Kerry's Code
    Public ComputersList As New List(Of ComputersClass)
    Public MonitorList As New List(Of MonitorClass)
    Public TelevisionsList As New List(Of TelevisionClass)
    Public ServicesList As New List(Of ServicesClass)

    Private Sub ComputersBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Validate()
        Me.ComputersBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.CompKCCDataSet)
    End Sub
    'Kevin's Code
    Private Sub PlaceAnOrderForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'CompKCCDataSet.Services' table. You can move, or remove it, as needed.
        Me.ServicesTableAdapter.Fill(Me.CompKCCDataSet.Services)
        'TODO: This line of code loads data into the 'CompKCCDataSet.Televisions' table. You can move, or remove it, as needed.
        Me.TelevisionsTableAdapter.Fill(Me.CompKCCDataSet.Televisions)
        'TODO: This line of code loads data into the 'CompKCCDataSet.Monitors' table. You can move, or remove it, as needed.
        Me.MonitorsTableAdapter.Fill(Me.CompKCCDataSet.Monitors)
        'TODO: This line of code loads data into the 'CompKCCDataSet.Computers' table. You can move, or remove it, as needed.
        Me.ComputersTableAdapter.Fill(Me.CompKCCDataSet.Computers)
    End Sub
    'Kevin's Code
    Private Sub MonitorsButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MonitorsButton.Click
        ProductTabControl.SelectedTab = MonitorsTabPage
    End Sub
    'Kevin's Code
    Private Sub ComputersButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComputersButton.Click
        ProductTabControl.SelectedTab = ComputersTabPage
    End Sub
    'Kevin's Code
    Private Sub TelevisionsButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TelevisionsButton.Click
        ProductTabControl.SelectedTab = TelevisionsTabPage
    End Sub
    'Kevin's Code
    Private Sub ServicesButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ServicesButton.Click
        ProductTabControl.SelectedTab = ServicesTabPage
    End Sub
    'Kevin's Code
    Private Sub ProductTabControl_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ProductTabControl.SelectedIndexChanged
        If ProductTabControl.SelectedIndex = 0 Then
            TelevisionsBindingNavigator.Visible = False
            ServicesBindingNavigator.Visible = False
            MonitorsBindingNavigator.Visible = False
            ComputersBindingNavigator.Visible = True
        ElseIf ProductTabControl.SelectedIndex = 1 Then
            TelevisionsBindingNavigator.Visible = False
            ServicesBindingNavigator.Visible = False
            MonitorsBindingNavigator.Visible = True
            ComputersBindingNavigator.Visible = False
        ElseIf ProductTabControl.SelectedIndex = 2 Then
            TelevisionsBindingNavigator.Visible = True
            ServicesBindingNavigator.Visible = False
            MonitorsBindingNavigator.Visible = False
            ComputersBindingNavigator.Visible = False
        ElseIf ProductTabControl.SelectedIndex = 3 Then
            TelevisionsBindingNavigator.Visible = False
            ServicesBindingNavigator.Visible = True
            MonitorsBindingNavigator.Visible = False
            ComputersBindingNavigator.Visible = False
        End If
    End Sub

    Private Sub ProductTabControl_TabIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ProductTabControl.TabIndexChanged
        If ProductTabControl.SelectedTab Is ComputersTabPage Then
            TelevisionsBindingNavigator.Visible = False
            ServicesBindingNavigator.Visible = False
            MonitorsBindingNavigator.Visible = False
            ComputersBindingNavigator.Visible = True
        ElseIf ProductTabControl.SelectedTab Is MonitorsTabPage Then
            TelevisionsBindingNavigator.Visible = False
            ServicesBindingNavigator.Visible = False
            MonitorsBindingNavigator.Visible = True
            ComputersBindingNavigator.Visible = False
        ElseIf ProductTabControl.SelectedTab Is TelevisionsTabPage Then
            TelevisionsBindingNavigator.Visible = True
            ServicesBindingNavigator.Visible = False
            MonitorsBindingNavigator.Visible = False
            ComputersBindingNavigator.Visible = False
        ElseIf ProductTabControl.SelectedTab Is ServicesTabPage Then
            TelevisionsBindingNavigator.Visible = False
            ServicesBindingNavigator.Visible = True
            MonitorsBindingNavigator.Visible = False
            ComputersBindingNavigator.Visible = False
        End If
    End Sub
    'Kerry's Code
    Private Sub CheckOutButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckOutButton.Click

        Dim NewOrderConfirmationForm As New OrderConfirmationForm
        NewOrderConfirmationForm.SubtotalLabel.Text = SubtotalLabel.Text
        NewOrderConfirmationForm.TaxLabel.Text = TaxLabel.Text
        NewOrderConfirmationForm.TotalLabel.Text = TotalLabel.Text
        For Each SingleProduct In ShoppingCartListBox.Items
            NewOrderConfirmationForm.ProductsListBox.Items.Add(SingleProduct)
        Next
        NewOrderConfirmationForm.ShowDialog()
    End Sub
    'Kerry's Code
    Private Sub AddToCartButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddToCartButton.Click
        Dim SubtotalDecimal As Decimal
        Dim TaxRateDecimal As Decimal = 4
        Dim TaxDecimal As Decimal
        If ProductTabControl.SelectedTab Is ComputersTabPage Then
            Dim Computer As New ComputersClass
            With Computer
                .ProductID = ComputerProductIDTextBox.Text
                .Type = ComputerTypeTextBox.Text
                .Brand = ComputerBrandTextBox.Text
                .Model = ComputerModelTextBox.Text
                .Cost = ComputerCostTextBox.Text
                .Description = ComputerDescriptionTextBox.Text
            End With
            ComputersList.Add(Computer)
        ElseIf ProductTabControl.SelectedTab Is MonitorsTabPage Then
            Dim Monitor As New MonitorClass
            With Monitor
                .ProductID = MonitorProductIDTextBox.Text
                .Brand = MonitorBrandTextBox.Text
                .Model = MonitorModelTextBox.Text
                .Type = MonitorTypeTextBox.Text
                .Size = MonitorSizeTextBox.Text
                .Cost = MonitorCostTextBox.Text
            End With
            MonitorList.Add(Monitor)
        ElseIf ProductTabControl.SelectedTab Is TelevisionsTabPage Then
            Dim Television As New TelevisionClass
            With Television
                .ProductID = TelevisionProductIDTextBox.Text
                .Type = TelevisionTypeTextBox.Text
                .Brand = TelevisionBrandTextBox.Text
                .Model = TelevisionModelTextBox.Text
                .Size = TelevisionSizeTextBox.Text
                .Cost = TelevisionCostTextBox.Text
            End With
            TelevisionsList.Add(Television)
        ElseIf ProductTabControl.SelectedTab Is ServicesTabPage Then
            Dim Services As New ServicesClass
            With Services
                .ProductID = ServiceProductIDTextBox.Text
                .Type = ServiceTypeTextBox.Text
                .Model = ServiceModelTextBox.Text
                .Cost = ServiceCostTextBox.Text
                .Description = ServiceDescriptionTextBox.Text
            End With
            ServicesList.Add(Services)
        End If

        ShoppingCartListBox.Items.Clear()
        For Each SingleComputer As ComputersClass In ComputersList
            ShoppingCartListBox.Items.Add(SingleComputer.ToString)
            SubtotalDecimal += SingleComputer.Cost
        Next

        For Each SingleMonitor As MonitorClass In MonitorList
            ShoppingCartListBox.Items.Add(SingleMonitor.ToString)
            SubtotalDecimal += SingleMonitor.Cost
        Next
        For Each SingleTelevision As TelevisionClass In TelevisionsList
            ShoppingCartListBox.Items.Add(SingleTelevision.ToString)
            SubtotalDecimal += SingleTelevision.Cost
        Next
        For Each SingleService As ServicesClass In ServicesList
            ShoppingCartListBox.Items.Add(SingleService.ToString)
            SubtotalDecimal += SingleService.Cost
        Next
        SubtotalLabel.Text = SubtotalDecimal.ToString("C")
        TaxDecimal = SubtotalDecimal * (TaxRateDecimal / 100)
        TaxLabel.Text = TaxDecimal.ToString("C")
        TotalLabel.Text = (SubtotalDecimal + TaxDecimal).ToString("C")
    End Sub
    'Kerry's Code
    Private Sub EmptyCartButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EmptyCartButton.Click
        SubtotalLabel.Text = ""
        TaxLabel.Text = ""
        TotalLabel.Text = ""
        ComputersList.Clear()
        MonitorList.Clear()
        ServicesList.Clear()
        TelevisionsList.Clear()
        ShoppingCartListBox.Items.Clear()
    End Sub
    'Kerry's code
    Private Sub SubmitToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SubmitToolStripButton.Click
        Dim ProductIDString As String = ProductIDToolStripTextBox.Text
        If ProductTabControl.SelectedTab Is ComputersTabPage Then
            Me.ComputersTableAdapter.FillByComputersProductID(Me.CompKCCDataSet.Computers, ProductIDString)
        ElseIf ProductTabControl.SelectedTab Is MonitorsTabPage Then
            Me.MonitorsTableAdapter.FillByMonitorsProductID(Me.CompKCCDataSet.Monitors, ProductIDString)
        ElseIf ProductTabControl.SelectedTab Is TelevisionsTabPage Then
            Me.TelevisionsTableAdapter.FillByTelevisionProductID(Me.CompKCCDataSet.Televisions, ProductIDString)
        ElseIf ProductTabControl.SelectedTab Is ServicesTabPage Then
            Me.ServicesTableAdapter.FillByServiceProductID(Me.CompKCCDataSet.Services, ProductIDString)
        End If
    End Sub
End Class