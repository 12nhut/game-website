﻿Option Strict On
Imports System.IO

Public Class CustomerOrdersForm

    Private Sub CustomerOrdersForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'CompKCCDataSet.CustomerOrders' table. You can move, or remove it, as needed.
        Me.CustomerOrdersTableAdapter.Fill(Me.CompKCCDataSet.CustomerOrders)
        If Me.Tag Is Nothing Then
            Me.CustomerOrdersTableAdapter.Fill(Me.CompKCCDataSet.CustomerOrders)
        Else
            Dim CustomerIDInteger As Integer = CInt(Me.Tag)
            Me.CustomerOrdersTableAdapter.FillByCustomerID(Me.CompKCCDataSet.CustomerOrders, CustomerIDInteger)
        End If
    End Sub

    Private Sub CustomerOrdersBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Validate()
        Me.CustomerOrdersBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.CompKCCDataSet)
    End Sub

    Private Sub CustomerOrdersDataGridView_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles CustomerOrdersDataGridView.CellContentClick
        'Pulls the index of the row that was clicked
        Dim RowIndex As Integer = e.RowIndex
        Dim Row As DataGridViewRow = CustomerOrdersDataGridView.Rows(RowIndex)
        'Pulls out just the cell from the row at position 0 (CustomerID)
        Dim Cell As DataGridViewCell = Row.Cells(0)

        'if the view employees datagridview button is clicked
        If e.ColumnIndex = 7 Then
            'creates a new AllEmployeesForm and shows it as a modeless form
            Dim NewAllEmployeesForm As New AllEmployeesForm
            Dim EmployeeIDInteger As Integer = CInt(Cell.Value)
            NewAllEmployeesForm.Tag = EmployeeIDInteger
            NewAllEmployeesForm.Show()
            'if the view customer datagridview button is clicked
        ElseIf e.ColumnIndex = 8 Then
            ''creates a new AllCustomersForm and shows it as a modeless form
            Dim NewAllCustombersForm As New AllCustomersForm
            Dim CustomerIDInteger As Integer = CInt(Cell.Value)
            NewAllCustombersForm.Tag = CustomerIDInteger
            NewAllCustombersForm.Show()
        End If
    End Sub

    Private Sub ViewReportButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ViewReportButton.Click
        'create a new CustomerOrdersReportForm and show it
        Dim NewCustomerordersReportForm As New CustomerOrdersReportForm
        NewCustomerordersReportForm.Show()
    End Sub
End Class
