﻿'Programmer:        Kevin Kruse
'Date:              12/07/2011
'Project:           Final Project Milestone 2
'Description:       
'This form is for Employees to login.  The data for employee login is in the access database.
'This form uses LINQ queries to search the dataset and compares values enter in the form
'against data from the database. 

Public Class LoginForm

    Private Sub LoginForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'CompKCCDataSet.Employees' table. You can move, or remove it, as needed.
        Me.EmployeesTableAdapter.Fill(Me.CompKCCDataSet.Employees)

        'LINQ Query to pull EmlpoyeeID's from the Employee table
        Dim AllEmployeeIDs = From SingleEmployeeID As CompKCCDataSet.EmployeesRow In CompKCCDataSet.Employees.Rows
                             Select SingleEmployeeID.EmployeeID

        'Adds the Employee ID's to the ComboBox
        For Each SingleEmployee In AllEmployeeIDs
            EmployeeIDComboBox.Items.Add(SingleEmployee)
        Next

        EmployeeIDComboBox.SelectedIndex = 0
    End Sub

    Private Sub LoginButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LoginButton.Click

        If EmployeeIDComboBox.SelectedIndex = 0 Then
            MessageBox.Show("Select an Employee ID", "Error!")
            Return
        Else
            Dim LoginIDInteger As Integer = CInt(EmployeeIDComboBox.SelectedItem)
            Dim PasswordEnteredString As String = PasswordTextBox.Text

            'LINQ Query to pull the Presumed Employee from the database
            Dim SelectedEmployeeID = From SingleEmployee As CompKCCDataSet.EmployeesRow In CompKCCDataSet.Employees.Rows
            Where (SingleEmployee.EmployeeID = LoginIDInteger)
                                     Select SingleEmployee

            'Compares the password from the database to the one on the form
            'If login is successful then write to event log and close the login form
            For Each SingleEmployee In SelectedEmployeeID
                If SingleEmployee.EmployeeID = LoginIDInteger And SingleEmployee.Password = PasswordEnteredString Then
                    Dim EventMessageString As String = "Login Successful!"
                    Dim SeverityLevelString As String = "Low"
                    MainForm.EventMessageLog(EventMessageString, SeverityLevelString)
                    MainForm.LoggedInEmployee = SingleEmployee.EmployeeID
                    Me.Close()
                    'Create a new CustomerMaintenance Form, then show it
                    Dim NewControlPanelForm As New ControlPanelForm
                    NewControlPanelForm.MdiParent = MainForm
                    NewControlPanelForm.Show()
                Else
                    MessageBox.Show("Wrong Password", "Error!")
                    PasswordTextBox.Clear()
                    PasswordTextBox.Focus()
                End If
            Next
        End If
    End Sub

    Private Sub LoginExitButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LoginExitButton.Click
        Application.Exit()
    End Sub

End Class