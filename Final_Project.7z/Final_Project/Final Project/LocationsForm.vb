﻿'Programmer:        Nhuan Thi
'Date:              11/30/2011
'Project:           Final Project Milestone 2

Public Class LocationsForm

    Private Sub LocationsBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Validate()
        Me.LocationsBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.CompKCCDataSet)

    End Sub

    Private Sub LocationsForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'CompKCCDataSet.Locations' table. You can move, or remove it, as needed.
        Me.LocationsTableAdapter.Fill(Me.CompKCCDataSet.Locations)
        'TODO: This line of code loads data into the 'CompKCCDataSet.Locations' table. You can move, or remove it, as needed.
        Me.LocationsTableAdapter.Fill(Me.CompKCCDataSet.Locations)

    End Sub

    Private Sub LocationsBindingNavigatorSaveItem_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LocationsBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.LocationsBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.CompKCCDataSet)

    End Sub
End Class