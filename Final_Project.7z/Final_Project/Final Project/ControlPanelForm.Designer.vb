﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ControlPanelForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.CustomersButton = New System.Windows.Forms.Button()
        Me.ViewOrdersButton = New System.Windows.Forms.Button()
        Me.EmployeesButton = New System.Windows.Forms.Button()
        Me.LocationsButton = New System.Windows.Forms.Button()
        Me.ReturnsButton = New System.Windows.Forms.Button()
        Me.PlaceOrderButton = New System.Windows.Forms.Button()
        Me.LogoPictureBox = New System.Windows.Forms.PictureBox()
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'CustomersButton
        '
        Me.CustomersButton.BackColor = System.Drawing.Color.Blue
        Me.CustomersButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CustomersButton.ForeColor = System.Drawing.Color.White
        Me.CustomersButton.Location = New System.Drawing.Point(188, 91)
        Me.CustomersButton.Name = "CustomersButton"
        Me.CustomersButton.Size = New System.Drawing.Size(190, 67)
        Me.CustomersButton.TabIndex = 0
        Me.CustomersButton.Text = "View Customers"
        Me.CustomersButton.UseVisualStyleBackColor = False
        '
        'ViewOrdersButton
        '
        Me.ViewOrdersButton.BackColor = System.Drawing.Color.Blue
        Me.ViewOrdersButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ViewOrdersButton.ForeColor = System.Drawing.Color.White
        Me.ViewOrdersButton.Location = New System.Drawing.Point(408, 91)
        Me.ViewOrdersButton.Name = "ViewOrdersButton"
        Me.ViewOrdersButton.Size = New System.Drawing.Size(190, 67)
        Me.ViewOrdersButton.TabIndex = 1
        Me.ViewOrdersButton.Text = "View Orders"
        Me.ViewOrdersButton.UseVisualStyleBackColor = False
        '
        'EmployeesButton
        '
        Me.EmployeesButton.BackColor = System.Drawing.Color.Blue
        Me.EmployeesButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EmployeesButton.ForeColor = System.Drawing.Color.White
        Me.EmployeesButton.Location = New System.Drawing.Point(188, 175)
        Me.EmployeesButton.Name = "EmployeesButton"
        Me.EmployeesButton.Size = New System.Drawing.Size(190, 67)
        Me.EmployeesButton.TabIndex = 2
        Me.EmployeesButton.Text = "View Employees"
        Me.EmployeesButton.UseVisualStyleBackColor = False
        '
        'LocationsButton
        '
        Me.LocationsButton.BackColor = System.Drawing.Color.Blue
        Me.LocationsButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LocationsButton.ForeColor = System.Drawing.Color.White
        Me.LocationsButton.Location = New System.Drawing.Point(408, 175)
        Me.LocationsButton.Name = "LocationsButton"
        Me.LocationsButton.Size = New System.Drawing.Size(190, 67)
        Me.LocationsButton.TabIndex = 3
        Me.LocationsButton.Text = "Locations"
        Me.LocationsButton.UseVisualStyleBackColor = False
        '
        'ReturnsButton
        '
        Me.ReturnsButton.BackColor = System.Drawing.Color.Blue
        Me.ReturnsButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ReturnsButton.ForeColor = System.Drawing.Color.White
        Me.ReturnsButton.Location = New System.Drawing.Point(188, 259)
        Me.ReturnsButton.Name = "ReturnsButton"
        Me.ReturnsButton.Size = New System.Drawing.Size(190, 67)
        Me.ReturnsButton.TabIndex = 4
        Me.ReturnsButton.Text = "View Returns"
        Me.ReturnsButton.UseVisualStyleBackColor = False
        '
        'PlaceOrderButton
        '
        Me.PlaceOrderButton.BackColor = System.Drawing.Color.Blue
        Me.PlaceOrderButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PlaceOrderButton.ForeColor = System.Drawing.Color.White
        Me.PlaceOrderButton.Location = New System.Drawing.Point(188, 352)
        Me.PlaceOrderButton.Name = "PlaceOrderButton"
        Me.PlaceOrderButton.Size = New System.Drawing.Size(190, 94)
        Me.PlaceOrderButton.TabIndex = 7
        Me.PlaceOrderButton.Text = "Place An Order"
        Me.PlaceOrderButton.UseVisualStyleBackColor = False
        '
        'LogoPictureBox
        '
        Me.LogoPictureBox.Image = Global.Final_Project.My.Resources.Resources.Best_Buy_logo
        Me.LogoPictureBox.Location = New System.Drawing.Point(419, 352)
        Me.LogoPictureBox.Name = "LogoPictureBox"
        Me.LogoPictureBox.Size = New System.Drawing.Size(179, 94)
        Me.LogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.LogoPictureBox.TabIndex = 6
        Me.LogoPictureBox.TabStop = False
        '
        'ControlPanelForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(793, 530)
        Me.Controls.Add(Me.PlaceOrderButton)
        Me.Controls.Add(Me.LogoPictureBox)
        Me.Controls.Add(Me.ReturnsButton)
        Me.Controls.Add(Me.LocationsButton)
        Me.Controls.Add(Me.EmployeesButton)
        Me.Controls.Add(Me.ViewOrdersButton)
        Me.Controls.Add(Me.CustomersButton)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "ControlPanelForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Control Panel"
        CType(Me.LogoPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents CustomersButton As System.Windows.Forms.Button
    Friend WithEvents ViewOrdersButton As System.Windows.Forms.Button
    Friend WithEvents EmployeesButton As System.Windows.Forms.Button
    Friend WithEvents LocationsButton As System.Windows.Forms.Button
    Friend WithEvents ReturnsButton As System.Windows.Forms.Button
    Friend WithEvents LogoPictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents PlaceOrderButton As System.Windows.Forms.Button
End Class
