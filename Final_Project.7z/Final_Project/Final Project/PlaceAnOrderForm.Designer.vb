﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PlaceAnOrderForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ProductIDLabel As System.Windows.Forms.Label
        Dim TypeLabel As System.Windows.Forms.Label
        Dim BrandLabel As System.Windows.Forms.Label
        Dim ModelLabel As System.Windows.Forms.Label
        Dim CostLabel As System.Windows.Forms.Label
        Dim DescriptionLabel As System.Windows.Forms.Label
        Dim ProductIDLabel1 As System.Windows.Forms.Label
        Dim BrandLabel1 As System.Windows.Forms.Label
        Dim ModelLabel1 As System.Windows.Forms.Label
        Dim TypeLabel1 As System.Windows.Forms.Label
        Dim SizeLabel As System.Windows.Forms.Label
        Dim CostLabel1 As System.Windows.Forms.Label
        Dim ProductIDLabel2 As System.Windows.Forms.Label
        Dim TypeLabel2 As System.Windows.Forms.Label
        Dim BrandLabel2 As System.Windows.Forms.Label
        Dim ModelLabel2 As System.Windows.Forms.Label
        Dim SizeLabel1 As System.Windows.Forms.Label
        Dim CostLabel2 As System.Windows.Forms.Label
        Dim CostLabel3 As System.Windows.Forms.Label
        Dim DescriptionLabel1 As System.Windows.Forms.Label
        Dim ModelLabel3 As System.Windows.Forms.Label
        Dim TypeLabel3 As System.Windows.Forms.Label
        Dim ProductIDLabel3 As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(PlaceAnOrderForm))
        Me.TelevisionsButton = New System.Windows.Forms.Button()
        Me.MonitorsButton = New System.Windows.Forms.Button()
        Me.ComputersButton = New System.Windows.Forms.Button()
        Me.ServicesButton = New System.Windows.Forms.Button()
        Me.CompKCCDataSet = New Final_Project.CompKCCDataSet()
        Me.ComputersBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ComputersTableAdapter = New Final_Project.CompKCCDataSetTableAdapters.ComputersTableAdapter()
        Me.TableAdapterManager = New Final_Project.CompKCCDataSetTableAdapters.TableAdapterManager()
        Me.ComputersBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ComputersBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.ComputerProductIDTextBox = New System.Windows.Forms.TextBox()
        Me.ComputerTypeTextBox = New System.Windows.Forms.TextBox()
        Me.ComputerBrandTextBox = New System.Windows.Forms.TextBox()
        Me.ComputerModelTextBox = New System.Windows.Forms.TextBox()
        Me.ComputerCostTextBox = New System.Windows.Forms.TextBox()
        Me.ComputerDescriptionTextBox = New System.Windows.Forms.TextBox()
        Me.MonitorsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.MonitorsTableAdapter = New Final_Project.CompKCCDataSetTableAdapters.MonitorsTableAdapter()
        Me.ComputersGroupBox = New System.Windows.Forms.GroupBox()
        Me.AddToCartButton = New System.Windows.Forms.Button()
        Me.MonitorProductIDTextBox = New System.Windows.Forms.TextBox()
        Me.MonitorBrandTextBox = New System.Windows.Forms.TextBox()
        Me.MonitorModelTextBox = New System.Windows.Forms.TextBox()
        Me.MonitorTypeTextBox = New System.Windows.Forms.TextBox()
        Me.MonitorSizeTextBox = New System.Windows.Forms.TextBox()
        Me.MonitorCostTextBox = New System.Windows.Forms.TextBox()
        Me.MonitorsGroupBox = New System.Windows.Forms.GroupBox()
        Me.MonitorsBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem1 = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem1 = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem1 = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem1 = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem1 = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem1 = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem1 = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem1 = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.TelevisionsGroupBox = New System.Windows.Forms.GroupBox()
        Me.TelevisionProductIDTextBox = New System.Windows.Forms.TextBox()
        Me.TelevisionsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TelevisionTypeTextBox = New System.Windows.Forms.TextBox()
        Me.TelevisionBrandTextBox = New System.Windows.Forms.TextBox()
        Me.TelevisionModelTextBox = New System.Windows.Forms.TextBox()
        Me.TelevisionSizeTextBox = New System.Windows.Forms.TextBox()
        Me.TelevisionCostTextBox = New System.Windows.Forms.TextBox()
        Me.TelevisionsTableAdapter = New Final_Project.CompKCCDataSetTableAdapters.TelevisionsTableAdapter()
        Me.TelevisionsBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem2 = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem2 = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem2 = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem2 = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem2 = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem2 = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator7 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem2 = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem2 = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator8 = New System.Windows.Forms.ToolStripSeparator()
        Me.ServicesBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ServicesTableAdapter = New Final_Project.CompKCCDataSetTableAdapters.ServicesTableAdapter()
        Me.ServicesBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem3 = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem3 = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem3 = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem3 = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem3 = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator9 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem3 = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator10 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem3 = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem3 = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator11 = New System.Windows.Forms.ToolStripSeparator()
        Me.ProductTabControl = New System.Windows.Forms.TabControl()
        Me.ComputersTabPage = New System.Windows.Forms.TabPage()
        Me.MonitorsTabPage = New System.Windows.Forms.TabPage()
        Me.TelevisionsTabPage = New System.Windows.Forms.TabPage()
        Me.ServicesTabPage = New System.Windows.Forms.TabPage()
        Me.ServicesGroupBox = New System.Windows.Forms.GroupBox()
        Me.ServiceProductIDTextBox = New System.Windows.Forms.TextBox()
        Me.ServiceTypeTextBox = New System.Windows.Forms.TextBox()
        Me.ServiceModelTextBox = New System.Windows.Forms.TextBox()
        Me.ServiceDescriptionTextBox = New System.Windows.Forms.TextBox()
        Me.ServiceCostTextBox = New System.Windows.Forms.TextBox()
        Me.ShoppingCartListBox = New System.Windows.Forms.ListBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.CheckOutButton = New System.Windows.Forms.Button()
        Me.EmptyCartButton = New System.Windows.Forms.Button()
        Me.SubtotalLabel = New System.Windows.Forms.Label()
        Me.TaxLabel = New System.Windows.Forms.Label()
        Me.TotalLabel = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.ToolStripLabel1 = New System.Windows.Forms.ToolStripLabel()
        Me.ProductIDToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.SubmitToolStripButton = New System.Windows.Forms.ToolStripButton()
        ProductIDLabel = New System.Windows.Forms.Label()
        TypeLabel = New System.Windows.Forms.Label()
        BrandLabel = New System.Windows.Forms.Label()
        ModelLabel = New System.Windows.Forms.Label()
        CostLabel = New System.Windows.Forms.Label()
        DescriptionLabel = New System.Windows.Forms.Label()
        ProductIDLabel1 = New System.Windows.Forms.Label()
        BrandLabel1 = New System.Windows.Forms.Label()
        ModelLabel1 = New System.Windows.Forms.Label()
        TypeLabel1 = New System.Windows.Forms.Label()
        SizeLabel = New System.Windows.Forms.Label()
        CostLabel1 = New System.Windows.Forms.Label()
        ProductIDLabel2 = New System.Windows.Forms.Label()
        TypeLabel2 = New System.Windows.Forms.Label()
        BrandLabel2 = New System.Windows.Forms.Label()
        ModelLabel2 = New System.Windows.Forms.Label()
        SizeLabel1 = New System.Windows.Forms.Label()
        CostLabel2 = New System.Windows.Forms.Label()
        CostLabel3 = New System.Windows.Forms.Label()
        DescriptionLabel1 = New System.Windows.Forms.Label()
        ModelLabel3 = New System.Windows.Forms.Label()
        TypeLabel3 = New System.Windows.Forms.Label()
        ProductIDLabel3 = New System.Windows.Forms.Label()
        CType(Me.CompKCCDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ComputersBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ComputersBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ComputersBindingNavigator.SuspendLayout()
        CType(Me.MonitorsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ComputersGroupBox.SuspendLayout()
        Me.MonitorsGroupBox.SuspendLayout()
        CType(Me.MonitorsBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MonitorsBindingNavigator.SuspendLayout()
        Me.TelevisionsGroupBox.SuspendLayout()
        CType(Me.TelevisionsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TelevisionsBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TelevisionsBindingNavigator.SuspendLayout()
        CType(Me.ServicesBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ServicesBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ServicesBindingNavigator.SuspendLayout()
        Me.ProductTabControl.SuspendLayout()
        Me.ComputersTabPage.SuspendLayout()
        Me.MonitorsTabPage.SuspendLayout()
        Me.TelevisionsTabPage.SuspendLayout()
        Me.ServicesTabPage.SuspendLayout()
        Me.ServicesGroupBox.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ProductIDLabel
        '
        ProductIDLabel.AutoSize = True
        ProductIDLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        ProductIDLabel.Location = New System.Drawing.Point(6, 32)
        ProductIDLabel.Name = "ProductIDLabel"
        ProductIDLabel.Size = New System.Drawing.Size(89, 20)
        ProductIDLabel.TabIndex = 5
        ProductIDLabel.Text = "Product ID:"
        '
        'TypeLabel
        '
        TypeLabel.AutoSize = True
        TypeLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        TypeLabel.Location = New System.Drawing.Point(48, 74)
        TypeLabel.Name = "TypeLabel"
        TypeLabel.Size = New System.Drawing.Size(47, 20)
        TypeLabel.TabIndex = 7
        TypeLabel.Text = "Type:"
        '
        'BrandLabel
        '
        BrandLabel.AutoSize = True
        BrandLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        BrandLabel.Location = New System.Drawing.Point(39, 116)
        BrandLabel.Name = "BrandLabel"
        BrandLabel.Size = New System.Drawing.Size(56, 20)
        BrandLabel.TabIndex = 9
        BrandLabel.Text = "Brand:"
        '
        'ModelLabel
        '
        ModelLabel.AutoSize = True
        ModelLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        ModelLabel.Location = New System.Drawing.Point(39, 158)
        ModelLabel.Name = "ModelLabel"
        ModelLabel.Size = New System.Drawing.Size(56, 20)
        ModelLabel.TabIndex = 11
        ModelLabel.Text = "Model:"
        '
        'CostLabel
        '
        CostLabel.AutoSize = True
        CostLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        CostLabel.Location = New System.Drawing.Point(49, 200)
        CostLabel.Name = "CostLabel"
        CostLabel.Size = New System.Drawing.Size(46, 20)
        CostLabel.TabIndex = 13
        CostLabel.Text = "Cost:"
        '
        'DescriptionLabel
        '
        DescriptionLabel.AutoSize = True
        DescriptionLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DescriptionLabel.Location = New System.Drawing.Point(2, 242)
        DescriptionLabel.Name = "DescriptionLabel"
        DescriptionLabel.Size = New System.Drawing.Size(93, 20)
        DescriptionLabel.TabIndex = 15
        DescriptionLabel.Text = "Description:"
        '
        'ProductIDLabel1
        '
        ProductIDLabel1.AutoSize = True
        ProductIDLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        ProductIDLabel1.Location = New System.Drawing.Point(5, 24)
        ProductIDLabel1.Name = "ProductIDLabel1"
        ProductIDLabel1.Size = New System.Drawing.Size(89, 20)
        ProductIDLabel1.TabIndex = 17
        ProductIDLabel1.Text = "Product ID:"
        '
        'BrandLabel1
        '
        BrandLabel1.AutoSize = True
        BrandLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        BrandLabel1.Location = New System.Drawing.Point(38, 66)
        BrandLabel1.Name = "BrandLabel1"
        BrandLabel1.Size = New System.Drawing.Size(56, 20)
        BrandLabel1.TabIndex = 19
        BrandLabel1.Text = "Brand:"
        '
        'ModelLabel1
        '
        ModelLabel1.AutoSize = True
        ModelLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        ModelLabel1.Location = New System.Drawing.Point(38, 108)
        ModelLabel1.Name = "ModelLabel1"
        ModelLabel1.Size = New System.Drawing.Size(56, 20)
        ModelLabel1.TabIndex = 21
        ModelLabel1.Text = "Model:"
        '
        'TypeLabel1
        '
        TypeLabel1.AutoSize = True
        TypeLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        TypeLabel1.Location = New System.Drawing.Point(47, 150)
        TypeLabel1.Name = "TypeLabel1"
        TypeLabel1.Size = New System.Drawing.Size(47, 20)
        TypeLabel1.TabIndex = 23
        TypeLabel1.Text = "Type:"
        '
        'SizeLabel
        '
        SizeLabel.AutoSize = True
        SizeLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        SizeLabel.Location = New System.Drawing.Point(50, 192)
        SizeLabel.Name = "SizeLabel"
        SizeLabel.Size = New System.Drawing.Size(44, 20)
        SizeLabel.TabIndex = 25
        SizeLabel.Text = "Size:"
        '
        'CostLabel1
        '
        CostLabel1.AutoSize = True
        CostLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        CostLabel1.Location = New System.Drawing.Point(48, 234)
        CostLabel1.Name = "CostLabel1"
        CostLabel1.Size = New System.Drawing.Size(46, 20)
        CostLabel1.TabIndex = 27
        CostLabel1.Text = "Cost:"
        '
        'ProductIDLabel2
        '
        ProductIDLabel2.AutoSize = True
        ProductIDLabel2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        ProductIDLabel2.Location = New System.Drawing.Point(6, 24)
        ProductIDLabel2.Name = "ProductIDLabel2"
        ProductIDLabel2.Size = New System.Drawing.Size(89, 20)
        ProductIDLabel2.TabIndex = 0
        ProductIDLabel2.Text = "Product ID:"
        '
        'TypeLabel2
        '
        TypeLabel2.AutoSize = True
        TypeLabel2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        TypeLabel2.Location = New System.Drawing.Point(48, 66)
        TypeLabel2.Name = "TypeLabel2"
        TypeLabel2.Size = New System.Drawing.Size(47, 20)
        TypeLabel2.TabIndex = 2
        TypeLabel2.Text = "Type:"
        '
        'BrandLabel2
        '
        BrandLabel2.AutoSize = True
        BrandLabel2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        BrandLabel2.Location = New System.Drawing.Point(39, 108)
        BrandLabel2.Name = "BrandLabel2"
        BrandLabel2.Size = New System.Drawing.Size(56, 20)
        BrandLabel2.TabIndex = 4
        BrandLabel2.Text = "Brand:"
        '
        'ModelLabel2
        '
        ModelLabel2.AutoSize = True
        ModelLabel2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        ModelLabel2.Location = New System.Drawing.Point(39, 150)
        ModelLabel2.Name = "ModelLabel2"
        ModelLabel2.Size = New System.Drawing.Size(56, 20)
        ModelLabel2.TabIndex = 6
        ModelLabel2.Text = "Model:"
        '
        'SizeLabel1
        '
        SizeLabel1.AutoSize = True
        SizeLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        SizeLabel1.Location = New System.Drawing.Point(51, 192)
        SizeLabel1.Name = "SizeLabel1"
        SizeLabel1.Size = New System.Drawing.Size(44, 20)
        SizeLabel1.TabIndex = 8
        SizeLabel1.Text = "Size:"
        '
        'CostLabel2
        '
        CostLabel2.AutoSize = True
        CostLabel2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        CostLabel2.Location = New System.Drawing.Point(49, 234)
        CostLabel2.Name = "CostLabel2"
        CostLabel2.Size = New System.Drawing.Size(46, 20)
        CostLabel2.TabIndex = 10
        CostLabel2.Text = "Cost:"
        '
        'CostLabel3
        '
        CostLabel3.AutoSize = True
        CostLabel3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        CostLabel3.Location = New System.Drawing.Point(50, 147)
        CostLabel3.Name = "CostLabel3"
        CostLabel3.Size = New System.Drawing.Size(46, 20)
        CostLabel3.TabIndex = 8
        CostLabel3.Text = "Cost:"
        '
        'DescriptionLabel1
        '
        DescriptionLabel1.AutoSize = True
        DescriptionLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DescriptionLabel1.Location = New System.Drawing.Point(3, 187)
        DescriptionLabel1.Name = "DescriptionLabel1"
        DescriptionLabel1.Size = New System.Drawing.Size(93, 20)
        DescriptionLabel1.TabIndex = 6
        DescriptionLabel1.Text = "Description:"
        '
        'ModelLabel3
        '
        ModelLabel3.AutoSize = True
        ModelLabel3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        ModelLabel3.Location = New System.Drawing.Point(41, 109)
        ModelLabel3.Name = "ModelLabel3"
        ModelLabel3.Size = New System.Drawing.Size(56, 20)
        ModelLabel3.TabIndex = 4
        ModelLabel3.Text = "Model:"
        '
        'TypeLabel3
        '
        TypeLabel3.AutoSize = True
        TypeLabel3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        TypeLabel3.Location = New System.Drawing.Point(50, 67)
        TypeLabel3.Name = "TypeLabel3"
        TypeLabel3.Size = New System.Drawing.Size(47, 20)
        TypeLabel3.TabIndex = 2
        TypeLabel3.Text = "Type:"
        '
        'ProductIDLabel3
        '
        ProductIDLabel3.AutoSize = True
        ProductIDLabel3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        ProductIDLabel3.Location = New System.Drawing.Point(8, 25)
        ProductIDLabel3.Name = "ProductIDLabel3"
        ProductIDLabel3.Size = New System.Drawing.Size(89, 20)
        ProductIDLabel3.TabIndex = 0
        ProductIDLabel3.Text = "Product ID:"
        '
        'TelevisionsButton
        '
        Me.TelevisionsButton.BackColor = System.Drawing.Color.Blue
        Me.TelevisionsButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TelevisionsButton.ForeColor = System.Drawing.Color.White
        Me.TelevisionsButton.Location = New System.Drawing.Point(343, 49)
        Me.TelevisionsButton.Name = "TelevisionsButton"
        Me.TelevisionsButton.Size = New System.Drawing.Size(156, 57)
        Me.TelevisionsButton.TabIndex = 1
        Me.TelevisionsButton.Text = "Televisions"
        Me.TelevisionsButton.UseVisualStyleBackColor = False
        '
        'MonitorsButton
        '
        Me.MonitorsButton.BackColor = System.Drawing.Color.Blue
        Me.MonitorsButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MonitorsButton.ForeColor = System.Drawing.Color.White
        Me.MonitorsButton.Location = New System.Drawing.Point(171, 49)
        Me.MonitorsButton.Name = "MonitorsButton"
        Me.MonitorsButton.Size = New System.Drawing.Size(156, 57)
        Me.MonitorsButton.TabIndex = 2
        Me.MonitorsButton.Text = "Monitors"
        Me.MonitorsButton.UseVisualStyleBackColor = False
        '
        'ComputersButton
        '
        Me.ComputersButton.BackColor = System.Drawing.Color.Blue
        Me.ComputersButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComputersButton.ForeColor = System.Drawing.Color.White
        Me.ComputersButton.Location = New System.Drawing.Point(0, 49)
        Me.ComputersButton.Name = "ComputersButton"
        Me.ComputersButton.Size = New System.Drawing.Size(156, 57)
        Me.ComputersButton.TabIndex = 3
        Me.ComputersButton.Text = "Computers"
        Me.ComputersButton.UseVisualStyleBackColor = False
        '
        'ServicesButton
        '
        Me.ServicesButton.BackColor = System.Drawing.Color.Blue
        Me.ServicesButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ServicesButton.ForeColor = System.Drawing.Color.White
        Me.ServicesButton.Location = New System.Drawing.Point(516, 49)
        Me.ServicesButton.Name = "ServicesButton"
        Me.ServicesButton.Size = New System.Drawing.Size(156, 57)
        Me.ServicesButton.TabIndex = 4
        Me.ServicesButton.Text = "Services"
        Me.ServicesButton.UseVisualStyleBackColor = False
        '
        'CompKCCDataSet
        '
        Me.CompKCCDataSet.DataSetName = "CompKCCDataSet"
        Me.CompKCCDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ComputersBindingSource
        '
        Me.ComputersBindingSource.DataMember = "Computers"
        Me.ComputersBindingSource.DataSource = Me.CompKCCDataSet
        '
        'ComputersTableAdapter
        '
        Me.ComputersTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.ComputersTableAdapter = Me.ComputersTableAdapter
        Me.TableAdapterManager.CustomerOrdersTableAdapter = Nothing
        Me.TableAdapterManager.CustomersTableAdapter = Nothing
        Me.TableAdapterManager.EmployeesTableAdapter = Nothing
        Me.TableAdapterManager.InvoicesTableAdapter = Nothing
        Me.TableAdapterManager.LocationsTableAdapter = Nothing
        Me.TableAdapterManager.MonitorsTableAdapter = Nothing
        Me.TableAdapterManager.ProductReturnsTableAdapter = Nothing
        Me.TableAdapterManager.ServicesTableAdapter = Nothing
        Me.TableAdapterManager.TelevisionsTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = Final_Project.CompKCCDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'ComputersBindingNavigator
        '
        Me.ComputersBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.ComputersBindingNavigator.BindingSource = Me.ComputersBindingSource
        Me.ComputersBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.ComputersBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.ComputersBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.ComputersBindingNavigatorSaveItem})
        Me.ComputersBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.ComputersBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.ComputersBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.ComputersBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.ComputersBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.ComputersBindingNavigator.Name = "ComputersBindingNavigator"
        Me.ComputersBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.ComputersBindingNavigator.Size = New System.Drawing.Size(709, 25)
        Me.ComputersBindingNavigator.TabIndex = 5
        Me.ComputersBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'ComputersBindingNavigatorSaveItem
        '
        Me.ComputersBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ComputersBindingNavigatorSaveItem.Image = CType(resources.GetObject("ComputersBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.ComputersBindingNavigatorSaveItem.Name = "ComputersBindingNavigatorSaveItem"
        Me.ComputersBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.ComputersBindingNavigatorSaveItem.Text = "Save Data"
        '
        'ComputerProductIDTextBox
        '
        Me.ComputerProductIDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ComputersBindingSource, "ProductID", True))
        Me.ComputerProductIDTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComputerProductIDTextBox.Location = New System.Drawing.Point(111, 29)
        Me.ComputerProductIDTextBox.Name = "ComputerProductIDTextBox"
        Me.ComputerProductIDTextBox.Size = New System.Drawing.Size(213, 26)
        Me.ComputerProductIDTextBox.TabIndex = 6
        '
        'ComputerTypeTextBox
        '
        Me.ComputerTypeTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ComputersBindingSource, "Type", True))
        Me.ComputerTypeTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComputerTypeTextBox.Location = New System.Drawing.Point(111, 71)
        Me.ComputerTypeTextBox.Name = "ComputerTypeTextBox"
        Me.ComputerTypeTextBox.Size = New System.Drawing.Size(213, 26)
        Me.ComputerTypeTextBox.TabIndex = 8
        '
        'ComputerBrandTextBox
        '
        Me.ComputerBrandTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ComputersBindingSource, "Brand", True))
        Me.ComputerBrandTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComputerBrandTextBox.Location = New System.Drawing.Point(111, 113)
        Me.ComputerBrandTextBox.Name = "ComputerBrandTextBox"
        Me.ComputerBrandTextBox.Size = New System.Drawing.Size(213, 26)
        Me.ComputerBrandTextBox.TabIndex = 10
        '
        'ComputerModelTextBox
        '
        Me.ComputerModelTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ComputersBindingSource, "Model", True))
        Me.ComputerModelTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComputerModelTextBox.Location = New System.Drawing.Point(111, 155)
        Me.ComputerModelTextBox.Name = "ComputerModelTextBox"
        Me.ComputerModelTextBox.Size = New System.Drawing.Size(213, 26)
        Me.ComputerModelTextBox.TabIndex = 12
        '
        'ComputerCostTextBox
        '
        Me.ComputerCostTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ComputersBindingSource, "Cost", True))
        Me.ComputerCostTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComputerCostTextBox.Location = New System.Drawing.Point(111, 197)
        Me.ComputerCostTextBox.Name = "ComputerCostTextBox"
        Me.ComputerCostTextBox.Size = New System.Drawing.Size(100, 26)
        Me.ComputerCostTextBox.TabIndex = 14
        '
        'ComputerDescriptionTextBox
        '
        Me.ComputerDescriptionTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ComputersBindingSource, "Description", True))
        Me.ComputerDescriptionTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComputerDescriptionTextBox.Location = New System.Drawing.Point(111, 239)
        Me.ComputerDescriptionTextBox.Name = "ComputerDescriptionTextBox"
        Me.ComputerDescriptionTextBox.Size = New System.Drawing.Size(519, 26)
        Me.ComputerDescriptionTextBox.TabIndex = 16
        '
        'MonitorsBindingSource
        '
        Me.MonitorsBindingSource.DataMember = "Monitors"
        Me.MonitorsBindingSource.DataSource = Me.CompKCCDataSet
        '
        'MonitorsTableAdapter
        '
        Me.MonitorsTableAdapter.ClearBeforeFill = True
        '
        'ComputersGroupBox
        '
        Me.ComputersGroupBox.Controls.Add(ProductIDLabel)
        Me.ComputersGroupBox.Controls.Add(Me.ComputerDescriptionTextBox)
        Me.ComputersGroupBox.Controls.Add(Me.ComputerProductIDTextBox)
        Me.ComputersGroupBox.Controls.Add(DescriptionLabel)
        Me.ComputersGroupBox.Controls.Add(TypeLabel)
        Me.ComputersGroupBox.Controls.Add(Me.ComputerCostTextBox)
        Me.ComputersGroupBox.Controls.Add(Me.ComputerTypeTextBox)
        Me.ComputersGroupBox.Controls.Add(CostLabel)
        Me.ComputersGroupBox.Controls.Add(BrandLabel)
        Me.ComputersGroupBox.Controls.Add(Me.ComputerModelTextBox)
        Me.ComputersGroupBox.Controls.Add(Me.ComputerBrandTextBox)
        Me.ComputersGroupBox.Controls.Add(ModelLabel)
        Me.ComputersGroupBox.Location = New System.Drawing.Point(6, 11)
        Me.ComputersGroupBox.Name = "ComputersGroupBox"
        Me.ComputersGroupBox.Size = New System.Drawing.Size(649, 275)
        Me.ComputersGroupBox.TabIndex = 17
        Me.ComputersGroupBox.TabStop = False
        Me.ComputersGroupBox.Text = "Computers"
        '
        'AddToCartButton
        '
        Me.AddToCartButton.BackColor = System.Drawing.Color.Blue
        Me.AddToCartButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AddToCartButton.ForeColor = System.Drawing.Color.White
        Me.AddToCartButton.Location = New System.Drawing.Point(555, 451)
        Me.AddToCartButton.Name = "AddToCartButton"
        Me.AddToCartButton.Size = New System.Drawing.Size(131, 35)
        Me.AddToCartButton.TabIndex = 46
        Me.AddToCartButton.Text = "Add to Cart"
        Me.AddToCartButton.UseVisualStyleBackColor = False
        '
        'MonitorProductIDTextBox
        '
        Me.MonitorProductIDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.MonitorsBindingSource, "ProductID", True))
        Me.MonitorProductIDTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MonitorProductIDTextBox.Location = New System.Drawing.Point(111, 24)
        Me.MonitorProductIDTextBox.Name = "MonitorProductIDTextBox"
        Me.MonitorProductIDTextBox.Size = New System.Drawing.Size(213, 26)
        Me.MonitorProductIDTextBox.TabIndex = 18
        '
        'MonitorBrandTextBox
        '
        Me.MonitorBrandTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.MonitorsBindingSource, "Brand", True))
        Me.MonitorBrandTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MonitorBrandTextBox.Location = New System.Drawing.Point(111, 66)
        Me.MonitorBrandTextBox.Name = "MonitorBrandTextBox"
        Me.MonitorBrandTextBox.Size = New System.Drawing.Size(213, 26)
        Me.MonitorBrandTextBox.TabIndex = 20
        '
        'MonitorModelTextBox
        '
        Me.MonitorModelTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.MonitorsBindingSource, "Model", True))
        Me.MonitorModelTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MonitorModelTextBox.Location = New System.Drawing.Point(111, 108)
        Me.MonitorModelTextBox.Name = "MonitorModelTextBox"
        Me.MonitorModelTextBox.Size = New System.Drawing.Size(213, 26)
        Me.MonitorModelTextBox.TabIndex = 22
        '
        'MonitorTypeTextBox
        '
        Me.MonitorTypeTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.MonitorsBindingSource, "Type", True))
        Me.MonitorTypeTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MonitorTypeTextBox.Location = New System.Drawing.Point(111, 150)
        Me.MonitorTypeTextBox.Name = "MonitorTypeTextBox"
        Me.MonitorTypeTextBox.Size = New System.Drawing.Size(100, 26)
        Me.MonitorTypeTextBox.TabIndex = 24
        '
        'MonitorSizeTextBox
        '
        Me.MonitorSizeTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.MonitorsBindingSource, "Size", True))
        Me.MonitorSizeTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MonitorSizeTextBox.Location = New System.Drawing.Point(111, 192)
        Me.MonitorSizeTextBox.Name = "MonitorSizeTextBox"
        Me.MonitorSizeTextBox.Size = New System.Drawing.Size(100, 26)
        Me.MonitorSizeTextBox.TabIndex = 26
        '
        'MonitorCostTextBox
        '
        Me.MonitorCostTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.MonitorsBindingSource, "Cost", True))
        Me.MonitorCostTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MonitorCostTextBox.Location = New System.Drawing.Point(111, 234)
        Me.MonitorCostTextBox.Name = "MonitorCostTextBox"
        Me.MonitorCostTextBox.Size = New System.Drawing.Size(100, 26)
        Me.MonitorCostTextBox.TabIndex = 28
        '
        'MonitorsGroupBox
        '
        Me.MonitorsGroupBox.Controls.Add(ProductIDLabel1)
        Me.MonitorsGroupBox.Controls.Add(Me.MonitorProductIDTextBox)
        Me.MonitorsGroupBox.Controls.Add(BrandLabel1)
        Me.MonitorsGroupBox.Controls.Add(Me.MonitorBrandTextBox)
        Me.MonitorsGroupBox.Controls.Add(ModelLabel1)
        Me.MonitorsGroupBox.Controls.Add(TypeLabel1)
        Me.MonitorsGroupBox.Controls.Add(SizeLabel)
        Me.MonitorsGroupBox.Controls.Add(Me.MonitorModelTextBox)
        Me.MonitorsGroupBox.Controls.Add(CostLabel1)
        Me.MonitorsGroupBox.Controls.Add(Me.MonitorTypeTextBox)
        Me.MonitorsGroupBox.Controls.Add(Me.MonitorSizeTextBox)
        Me.MonitorsGroupBox.Controls.Add(Me.MonitorCostTextBox)
        Me.MonitorsGroupBox.Location = New System.Drawing.Point(6, 4)
        Me.MonitorsGroupBox.Name = "MonitorsGroupBox"
        Me.MonitorsGroupBox.Size = New System.Drawing.Size(648, 299)
        Me.MonitorsGroupBox.TabIndex = 29
        Me.MonitorsGroupBox.TabStop = False
        Me.MonitorsGroupBox.Text = "Monitors"
        '
        'MonitorsBindingNavigator
        '
        Me.MonitorsBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem1
        Me.MonitorsBindingNavigator.BindingSource = Me.MonitorsBindingSource
        Me.MonitorsBindingNavigator.CountItem = Me.BindingNavigatorCountItem1
        Me.MonitorsBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem1
        Me.MonitorsBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem1, Me.BindingNavigatorMovePreviousItem1, Me.BindingNavigatorSeparator3, Me.BindingNavigatorPositionItem1, Me.BindingNavigatorCountItem1, Me.BindingNavigatorSeparator4, Me.BindingNavigatorMoveNextItem1, Me.BindingNavigatorMoveLastItem1, Me.BindingNavigatorSeparator5, Me.BindingNavigatorAddNewItem1, Me.BindingNavigatorDeleteItem1})
        Me.MonitorsBindingNavigator.Location = New System.Drawing.Point(0, 75)
        Me.MonitorsBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem1
        Me.MonitorsBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem1
        Me.MonitorsBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem1
        Me.MonitorsBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem1
        Me.MonitorsBindingNavigator.Name = "MonitorsBindingNavigator"
        Me.MonitorsBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem1
        Me.MonitorsBindingNavigator.Size = New System.Drawing.Size(708, 25)
        Me.MonitorsBindingNavigator.TabIndex = 30
        Me.MonitorsBindingNavigator.Text = "BindingNavigator1"
        Me.MonitorsBindingNavigator.Visible = False
        '
        'BindingNavigatorAddNewItem1
        '
        Me.BindingNavigatorAddNewItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem1.Image = CType(resources.GetObject("BindingNavigatorAddNewItem1.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem1.Name = "BindingNavigatorAddNewItem1"
        Me.BindingNavigatorAddNewItem1.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem1.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem1.Text = "Add new"
        '
        'BindingNavigatorCountItem1
        '
        Me.BindingNavigatorCountItem1.Name = "BindingNavigatorCountItem1"
        Me.BindingNavigatorCountItem1.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem1.Text = "of {0}"
        Me.BindingNavigatorCountItem1.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem1
        '
        Me.BindingNavigatorDeleteItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem1.Image = CType(resources.GetObject("BindingNavigatorDeleteItem1.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem1.Name = "BindingNavigatorDeleteItem1"
        Me.BindingNavigatorDeleteItem1.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem1.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem1.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem1
        '
        Me.BindingNavigatorMoveFirstItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem1.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem1.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem1.Name = "BindingNavigatorMoveFirstItem1"
        Me.BindingNavigatorMoveFirstItem1.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem1.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem1.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem1
        '
        Me.BindingNavigatorMovePreviousItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem1.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem1.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem1.Name = "BindingNavigatorMovePreviousItem1"
        Me.BindingNavigatorMovePreviousItem1.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem1.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem1.Text = "Move previous"
        '
        'BindingNavigatorSeparator3
        '
        Me.BindingNavigatorSeparator3.Name = "BindingNavigatorSeparator3"
        Me.BindingNavigatorSeparator3.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem1
        '
        Me.BindingNavigatorPositionItem1.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem1.AutoSize = False
        Me.BindingNavigatorPositionItem1.Name = "BindingNavigatorPositionItem1"
        Me.BindingNavigatorPositionItem1.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem1.Text = "0"
        Me.BindingNavigatorPositionItem1.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator4
        '
        Me.BindingNavigatorSeparator4.Name = "BindingNavigatorSeparator4"
        Me.BindingNavigatorSeparator4.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem1
        '
        Me.BindingNavigatorMoveNextItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem1.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem1.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem1.Name = "BindingNavigatorMoveNextItem1"
        Me.BindingNavigatorMoveNextItem1.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem1.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem1.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem1
        '
        Me.BindingNavigatorMoveLastItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem1.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem1.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem1.Name = "BindingNavigatorMoveLastItem1"
        Me.BindingNavigatorMoveLastItem1.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem1.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem1.Text = "Move last"
        '
        'BindingNavigatorSeparator5
        '
        Me.BindingNavigatorSeparator5.Name = "BindingNavigatorSeparator5"
        Me.BindingNavigatorSeparator5.Size = New System.Drawing.Size(6, 25)
        '
        'TelevisionsGroupBox
        '
        Me.TelevisionsGroupBox.Controls.Add(ProductIDLabel2)
        Me.TelevisionsGroupBox.Controls.Add(Me.TelevisionProductIDTextBox)
        Me.TelevisionsGroupBox.Controls.Add(TypeLabel2)
        Me.TelevisionsGroupBox.Controls.Add(Me.TelevisionTypeTextBox)
        Me.TelevisionsGroupBox.Controls.Add(BrandLabel2)
        Me.TelevisionsGroupBox.Controls.Add(Me.TelevisionBrandTextBox)
        Me.TelevisionsGroupBox.Controls.Add(ModelLabel2)
        Me.TelevisionsGroupBox.Controls.Add(Me.TelevisionModelTextBox)
        Me.TelevisionsGroupBox.Controls.Add(SizeLabel1)
        Me.TelevisionsGroupBox.Controls.Add(Me.TelevisionSizeTextBox)
        Me.TelevisionsGroupBox.Controls.Add(CostLabel2)
        Me.TelevisionsGroupBox.Controls.Add(Me.TelevisionCostTextBox)
        Me.TelevisionsGroupBox.Location = New System.Drawing.Point(8, 6)
        Me.TelevisionsGroupBox.Name = "TelevisionsGroupBox"
        Me.TelevisionsGroupBox.Size = New System.Drawing.Size(648, 287)
        Me.TelevisionsGroupBox.TabIndex = 29
        Me.TelevisionsGroupBox.TabStop = False
        Me.TelevisionsGroupBox.Text = "Televisions"
        '
        'TelevisionProductIDTextBox
        '
        Me.TelevisionProductIDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TelevisionsBindingSource, "ProductID", True))
        Me.TelevisionProductIDTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TelevisionProductIDTextBox.Location = New System.Drawing.Point(111, 19)
        Me.TelevisionProductIDTextBox.Name = "TelevisionProductIDTextBox"
        Me.TelevisionProductIDTextBox.Size = New System.Drawing.Size(213, 26)
        Me.TelevisionProductIDTextBox.TabIndex = 1
        '
        'TelevisionsBindingSource
        '
        Me.TelevisionsBindingSource.DataMember = "Televisions"
        Me.TelevisionsBindingSource.DataSource = Me.CompKCCDataSet
        '
        'TelevisionTypeTextBox
        '
        Me.TelevisionTypeTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TelevisionsBindingSource, "Type", True))
        Me.TelevisionTypeTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TelevisionTypeTextBox.Location = New System.Drawing.Point(111, 61)
        Me.TelevisionTypeTextBox.Name = "TelevisionTypeTextBox"
        Me.TelevisionTypeTextBox.Size = New System.Drawing.Size(213, 26)
        Me.TelevisionTypeTextBox.TabIndex = 3
        '
        'TelevisionBrandTextBox
        '
        Me.TelevisionBrandTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TelevisionsBindingSource, "Brand", True))
        Me.TelevisionBrandTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TelevisionBrandTextBox.Location = New System.Drawing.Point(111, 103)
        Me.TelevisionBrandTextBox.Name = "TelevisionBrandTextBox"
        Me.TelevisionBrandTextBox.Size = New System.Drawing.Size(213, 26)
        Me.TelevisionBrandTextBox.TabIndex = 5
        '
        'TelevisionModelTextBox
        '
        Me.TelevisionModelTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TelevisionsBindingSource, "Model", True))
        Me.TelevisionModelTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TelevisionModelTextBox.Location = New System.Drawing.Point(111, 145)
        Me.TelevisionModelTextBox.Name = "TelevisionModelTextBox"
        Me.TelevisionModelTextBox.Size = New System.Drawing.Size(213, 26)
        Me.TelevisionModelTextBox.TabIndex = 7
        '
        'TelevisionSizeTextBox
        '
        Me.TelevisionSizeTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TelevisionsBindingSource, "Size", True))
        Me.TelevisionSizeTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TelevisionSizeTextBox.Location = New System.Drawing.Point(111, 187)
        Me.TelevisionSizeTextBox.Name = "TelevisionSizeTextBox"
        Me.TelevisionSizeTextBox.Size = New System.Drawing.Size(100, 26)
        Me.TelevisionSizeTextBox.TabIndex = 9
        '
        'TelevisionCostTextBox
        '
        Me.TelevisionCostTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TelevisionsBindingSource, "Cost", True))
        Me.TelevisionCostTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TelevisionCostTextBox.Location = New System.Drawing.Point(111, 229)
        Me.TelevisionCostTextBox.Name = "TelevisionCostTextBox"
        Me.TelevisionCostTextBox.Size = New System.Drawing.Size(100, 26)
        Me.TelevisionCostTextBox.TabIndex = 11
        '
        'TelevisionsTableAdapter
        '
        Me.TelevisionsTableAdapter.ClearBeforeFill = True
        '
        'TelevisionsBindingNavigator
        '
        Me.TelevisionsBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem2
        Me.TelevisionsBindingNavigator.BindingSource = Me.TelevisionsBindingSource
        Me.TelevisionsBindingNavigator.CountItem = Me.BindingNavigatorCountItem2
        Me.TelevisionsBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem2
        Me.TelevisionsBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem2, Me.BindingNavigatorMovePreviousItem2, Me.BindingNavigatorSeparator6, Me.BindingNavigatorPositionItem2, Me.BindingNavigatorCountItem2, Me.BindingNavigatorSeparator7, Me.BindingNavigatorMoveNextItem2, Me.BindingNavigatorMoveLastItem2, Me.BindingNavigatorSeparator8, Me.BindingNavigatorAddNewItem2, Me.BindingNavigatorDeleteItem2})
        Me.TelevisionsBindingNavigator.Location = New System.Drawing.Point(0, 50)
        Me.TelevisionsBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem2
        Me.TelevisionsBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem2
        Me.TelevisionsBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem2
        Me.TelevisionsBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem2
        Me.TelevisionsBindingNavigator.Name = "TelevisionsBindingNavigator"
        Me.TelevisionsBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem2
        Me.TelevisionsBindingNavigator.Size = New System.Drawing.Size(708, 25)
        Me.TelevisionsBindingNavigator.TabIndex = 31
        Me.TelevisionsBindingNavigator.Text = "BindingNavigator1"
        Me.TelevisionsBindingNavigator.Visible = False
        '
        'BindingNavigatorAddNewItem2
        '
        Me.BindingNavigatorAddNewItem2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem2.Image = CType(resources.GetObject("BindingNavigatorAddNewItem2.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem2.Name = "BindingNavigatorAddNewItem2"
        Me.BindingNavigatorAddNewItem2.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem2.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem2.Text = "Add new"
        '
        'BindingNavigatorCountItem2
        '
        Me.BindingNavigatorCountItem2.Name = "BindingNavigatorCountItem2"
        Me.BindingNavigatorCountItem2.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem2.Text = "of {0}"
        Me.BindingNavigatorCountItem2.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem2
        '
        Me.BindingNavigatorDeleteItem2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem2.Image = CType(resources.GetObject("BindingNavigatorDeleteItem2.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem2.Name = "BindingNavigatorDeleteItem2"
        Me.BindingNavigatorDeleteItem2.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem2.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem2.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem2
        '
        Me.BindingNavigatorMoveFirstItem2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem2.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem2.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem2.Name = "BindingNavigatorMoveFirstItem2"
        Me.BindingNavigatorMoveFirstItem2.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem2.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem2.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem2
        '
        Me.BindingNavigatorMovePreviousItem2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem2.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem2.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem2.Name = "BindingNavigatorMovePreviousItem2"
        Me.BindingNavigatorMovePreviousItem2.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem2.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem2.Text = "Move previous"
        '
        'BindingNavigatorSeparator6
        '
        Me.BindingNavigatorSeparator6.Name = "BindingNavigatorSeparator6"
        Me.BindingNavigatorSeparator6.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem2
        '
        Me.BindingNavigatorPositionItem2.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem2.AutoSize = False
        Me.BindingNavigatorPositionItem2.Name = "BindingNavigatorPositionItem2"
        Me.BindingNavigatorPositionItem2.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem2.Text = "0"
        Me.BindingNavigatorPositionItem2.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator7
        '
        Me.BindingNavigatorSeparator7.Name = "BindingNavigatorSeparator7"
        Me.BindingNavigatorSeparator7.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem2
        '
        Me.BindingNavigatorMoveNextItem2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem2.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem2.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem2.Name = "BindingNavigatorMoveNextItem2"
        Me.BindingNavigatorMoveNextItem2.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem2.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem2.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem2
        '
        Me.BindingNavigatorMoveLastItem2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem2.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem2.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem2.Name = "BindingNavigatorMoveLastItem2"
        Me.BindingNavigatorMoveLastItem2.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem2.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem2.Text = "Move last"
        '
        'BindingNavigatorSeparator8
        '
        Me.BindingNavigatorSeparator8.Name = "BindingNavigatorSeparator8"
        Me.BindingNavigatorSeparator8.Size = New System.Drawing.Size(6, 25)
        '
        'ServicesBindingSource
        '
        Me.ServicesBindingSource.DataMember = "Services"
        Me.ServicesBindingSource.DataSource = Me.CompKCCDataSet
        '
        'ServicesTableAdapter
        '
        Me.ServicesTableAdapter.ClearBeforeFill = True
        '
        'ServicesBindingNavigator
        '
        Me.ServicesBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem3
        Me.ServicesBindingNavigator.BindingSource = Me.ServicesBindingSource
        Me.ServicesBindingNavigator.CountItem = Me.BindingNavigatorCountItem3
        Me.ServicesBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem3
        Me.ServicesBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem3, Me.BindingNavigatorMovePreviousItem3, Me.BindingNavigatorSeparator9, Me.BindingNavigatorPositionItem3, Me.BindingNavigatorCountItem3, Me.BindingNavigatorSeparator10, Me.BindingNavigatorMoveNextItem3, Me.BindingNavigatorMoveLastItem3, Me.BindingNavigatorSeparator11, Me.BindingNavigatorAddNewItem3, Me.BindingNavigatorDeleteItem3})
        Me.ServicesBindingNavigator.Location = New System.Drawing.Point(0, 25)
        Me.ServicesBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem3
        Me.ServicesBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem3
        Me.ServicesBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem3
        Me.ServicesBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem3
        Me.ServicesBindingNavigator.Name = "ServicesBindingNavigator"
        Me.ServicesBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem3
        Me.ServicesBindingNavigator.Size = New System.Drawing.Size(708, 25)
        Me.ServicesBindingNavigator.TabIndex = 32
        Me.ServicesBindingNavigator.Text = "BindingNavigator1"
        Me.ServicesBindingNavigator.Visible = False
        '
        'BindingNavigatorAddNewItem3
        '
        Me.BindingNavigatorAddNewItem3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem3.Image = CType(resources.GetObject("BindingNavigatorAddNewItem3.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem3.Name = "BindingNavigatorAddNewItem3"
        Me.BindingNavigatorAddNewItem3.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem3.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem3.Text = "Add new"
        '
        'BindingNavigatorCountItem3
        '
        Me.BindingNavigatorCountItem3.Name = "BindingNavigatorCountItem3"
        Me.BindingNavigatorCountItem3.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem3.Text = "of {0}"
        Me.BindingNavigatorCountItem3.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem3
        '
        Me.BindingNavigatorDeleteItem3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem3.Image = CType(resources.GetObject("BindingNavigatorDeleteItem3.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem3.Name = "BindingNavigatorDeleteItem3"
        Me.BindingNavigatorDeleteItem3.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem3.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem3.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem3
        '
        Me.BindingNavigatorMoveFirstItem3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem3.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem3.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem3.Name = "BindingNavigatorMoveFirstItem3"
        Me.BindingNavigatorMoveFirstItem3.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem3.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem3.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem3
        '
        Me.BindingNavigatorMovePreviousItem3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem3.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem3.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem3.Name = "BindingNavigatorMovePreviousItem3"
        Me.BindingNavigatorMovePreviousItem3.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem3.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem3.Text = "Move previous"
        '
        'BindingNavigatorSeparator9
        '
        Me.BindingNavigatorSeparator9.Name = "BindingNavigatorSeparator9"
        Me.BindingNavigatorSeparator9.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem3
        '
        Me.BindingNavigatorPositionItem3.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem3.AutoSize = False
        Me.BindingNavigatorPositionItem3.Name = "BindingNavigatorPositionItem3"
        Me.BindingNavigatorPositionItem3.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem3.Text = "0"
        Me.BindingNavigatorPositionItem3.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator10
        '
        Me.BindingNavigatorSeparator10.Name = "BindingNavigatorSeparator10"
        Me.BindingNavigatorSeparator10.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem3
        '
        Me.BindingNavigatorMoveNextItem3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem3.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem3.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem3.Name = "BindingNavigatorMoveNextItem3"
        Me.BindingNavigatorMoveNextItem3.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem3.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem3.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem3
        '
        Me.BindingNavigatorMoveLastItem3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem3.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem3.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem3.Name = "BindingNavigatorMoveLastItem3"
        Me.BindingNavigatorMoveLastItem3.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem3.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem3.Text = "Move last"
        '
        'BindingNavigatorSeparator11
        '
        Me.BindingNavigatorSeparator11.Name = "BindingNavigatorSeparator11"
        Me.BindingNavigatorSeparator11.Size = New System.Drawing.Size(6, 25)
        '
        'ProductTabControl
        '
        Me.ProductTabControl.Controls.Add(Me.ComputersTabPage)
        Me.ProductTabControl.Controls.Add(Me.MonitorsTabPage)
        Me.ProductTabControl.Controls.Add(Me.TelevisionsTabPage)
        Me.ProductTabControl.Controls.Add(Me.ServicesTabPage)
        Me.ProductTabControl.Location = New System.Drawing.Point(12, 112)
        Me.ProductTabControl.Name = "ProductTabControl"
        Me.ProductTabControl.SelectedIndex = 0
        Me.ProductTabControl.Size = New System.Drawing.Size(679, 333)
        Me.ProductTabControl.TabIndex = 33
        '
        'ComputersTabPage
        '
        Me.ComputersTabPage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ComputersTabPage.Controls.Add(Me.ComputersGroupBox)
        Me.ComputersTabPage.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComputersTabPage.Location = New System.Drawing.Point(4, 22)
        Me.ComputersTabPage.Name = "ComputersTabPage"
        Me.ComputersTabPage.Padding = New System.Windows.Forms.Padding(3)
        Me.ComputersTabPage.Size = New System.Drawing.Size(671, 307)
        Me.ComputersTabPage.TabIndex = 0
        Me.ComputersTabPage.Text = "Computers"
        Me.ComputersTabPage.UseVisualStyleBackColor = True
        '
        'MonitorsTabPage
        '
        Me.MonitorsTabPage.Controls.Add(Me.MonitorsGroupBox)
        Me.MonitorsTabPage.Location = New System.Drawing.Point(4, 22)
        Me.MonitorsTabPage.Name = "MonitorsTabPage"
        Me.MonitorsTabPage.Padding = New System.Windows.Forms.Padding(3)
        Me.MonitorsTabPage.Size = New System.Drawing.Size(671, 307)
        Me.MonitorsTabPage.TabIndex = 1
        Me.MonitorsTabPage.Text = "Monitors"
        Me.MonitorsTabPage.UseVisualStyleBackColor = True
        '
        'TelevisionsTabPage
        '
        Me.TelevisionsTabPage.Controls.Add(Me.TelevisionsGroupBox)
        Me.TelevisionsTabPage.Location = New System.Drawing.Point(4, 22)
        Me.TelevisionsTabPage.Name = "TelevisionsTabPage"
        Me.TelevisionsTabPage.Padding = New System.Windows.Forms.Padding(3)
        Me.TelevisionsTabPage.Size = New System.Drawing.Size(671, 307)
        Me.TelevisionsTabPage.TabIndex = 2
        Me.TelevisionsTabPage.Text = "Televisions"
        Me.TelevisionsTabPage.UseVisualStyleBackColor = True
        '
        'ServicesTabPage
        '
        Me.ServicesTabPage.Controls.Add(Me.ServicesGroupBox)
        Me.ServicesTabPage.Location = New System.Drawing.Point(4, 22)
        Me.ServicesTabPage.Name = "ServicesTabPage"
        Me.ServicesTabPage.Padding = New System.Windows.Forms.Padding(3)
        Me.ServicesTabPage.Size = New System.Drawing.Size(671, 307)
        Me.ServicesTabPage.TabIndex = 3
        Me.ServicesTabPage.Text = "Services"
        Me.ServicesTabPage.UseVisualStyleBackColor = True
        '
        'ServicesGroupBox
        '
        Me.ServicesGroupBox.Controls.Add(ProductIDLabel3)
        Me.ServicesGroupBox.Controls.Add(Me.ServiceProductIDTextBox)
        Me.ServicesGroupBox.Controls.Add(TypeLabel3)
        Me.ServicesGroupBox.Controls.Add(Me.ServiceTypeTextBox)
        Me.ServicesGroupBox.Controls.Add(ModelLabel3)
        Me.ServicesGroupBox.Controls.Add(Me.ServiceModelTextBox)
        Me.ServicesGroupBox.Controls.Add(DescriptionLabel1)
        Me.ServicesGroupBox.Controls.Add(Me.ServiceDescriptionTextBox)
        Me.ServicesGroupBox.Controls.Add(CostLabel3)
        Me.ServicesGroupBox.Controls.Add(Me.ServiceCostTextBox)
        Me.ServicesGroupBox.Location = New System.Drawing.Point(6, 6)
        Me.ServicesGroupBox.Name = "ServicesGroupBox"
        Me.ServicesGroupBox.Size = New System.Drawing.Size(649, 223)
        Me.ServicesGroupBox.TabIndex = 32
        Me.ServicesGroupBox.TabStop = False
        Me.ServicesGroupBox.Text = "Services"
        '
        'ServiceProductIDTextBox
        '
        Me.ServiceProductIDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ServicesBindingSource, "ProductID", True))
        Me.ServiceProductIDTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ServiceProductIDTextBox.Location = New System.Drawing.Point(113, 19)
        Me.ServiceProductIDTextBox.Name = "ServiceProductIDTextBox"
        Me.ServiceProductIDTextBox.Size = New System.Drawing.Size(213, 26)
        Me.ServiceProductIDTextBox.TabIndex = 1
        '
        'ServiceTypeTextBox
        '
        Me.ServiceTypeTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ServicesBindingSource, "Type", True))
        Me.ServiceTypeTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ServiceTypeTextBox.Location = New System.Drawing.Point(113, 61)
        Me.ServiceTypeTextBox.Name = "ServiceTypeTextBox"
        Me.ServiceTypeTextBox.Size = New System.Drawing.Size(213, 26)
        Me.ServiceTypeTextBox.TabIndex = 3
        '
        'ServiceModelTextBox
        '
        Me.ServiceModelTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ServicesBindingSource, "Model", True))
        Me.ServiceModelTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ServiceModelTextBox.Location = New System.Drawing.Point(113, 103)
        Me.ServiceModelTextBox.Name = "ServiceModelTextBox"
        Me.ServiceModelTextBox.Size = New System.Drawing.Size(213, 26)
        Me.ServiceModelTextBox.TabIndex = 5
        '
        'ServiceDescriptionTextBox
        '
        Me.ServiceDescriptionTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ServicesBindingSource, "Description", True))
        Me.ServiceDescriptionTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ServiceDescriptionTextBox.Location = New System.Drawing.Point(112, 181)
        Me.ServiceDescriptionTextBox.Name = "ServiceDescriptionTextBox"
        Me.ServiceDescriptionTextBox.Size = New System.Drawing.Size(520, 26)
        Me.ServiceDescriptionTextBox.TabIndex = 7
        '
        'ServiceCostTextBox
        '
        Me.ServiceCostTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ServicesBindingSource, "Cost", True))
        Me.ServiceCostTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ServiceCostTextBox.Location = New System.Drawing.Point(112, 141)
        Me.ServiceCostTextBox.Name = "ServiceCostTextBox"
        Me.ServiceCostTextBox.Size = New System.Drawing.Size(100, 26)
        Me.ServiceCostTextBox.TabIndex = 9
        '
        'ShoppingCartListBox
        '
        Me.ShoppingCartListBox.FormattingEnabled = True
        Me.ShoppingCartListBox.Location = New System.Drawing.Point(16, 510)
        Me.ShoppingCartListBox.Name = "ShoppingCartListBox"
        Me.ShoppingCartListBox.Size = New System.Drawing.Size(670, 134)
        Me.ShoppingCartListBox.TabIndex = 34
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(79, 484)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(115, 20)
        Me.Label1.TabIndex = 35
        Me.Label1.Text = "Shopping Cart:"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = Global.Final_Project.My.Resources.Resources.shopping_cart
        Me.PictureBox1.Image = Global.Final_Project.My.Resources.Resources.shopping_cart
        Me.PictureBox1.Location = New System.Drawing.Point(16, 464)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(57, 40)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 36
        Me.PictureBox1.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(520, 715)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(48, 20)
        Me.Label2.TabIndex = 37
        Me.Label2.Text = "Total:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(530, 687)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(38, 20)
        Me.Label3.TabIndex = 38
        Me.Label3.Text = "Tax:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(491, 659)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(77, 20)
        Me.Label4.TabIndex = 39
        Me.Label4.Text = "SubTotal:"
        '
        'CheckOutButton
        '
        Me.CheckOutButton.BackColor = System.Drawing.Color.Blue
        Me.CheckOutButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckOutButton.ForeColor = System.Drawing.Color.White
        Me.CheckOutButton.Location = New System.Drawing.Point(407, 753)
        Me.CheckOutButton.Name = "CheckOutButton"
        Me.CheckOutButton.Size = New System.Drawing.Size(131, 35)
        Me.CheckOutButton.TabIndex = 40
        Me.CheckOutButton.Text = "Check Out"
        Me.CheckOutButton.UseVisualStyleBackColor = False
        '
        'EmptyCartButton
        '
        Me.EmptyCartButton.BackColor = System.Drawing.Color.Blue
        Me.EmptyCartButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EmptyCartButton.ForeColor = System.Drawing.Color.White
        Me.EmptyCartButton.Location = New System.Drawing.Point(556, 753)
        Me.EmptyCartButton.Name = "EmptyCartButton"
        Me.EmptyCartButton.Size = New System.Drawing.Size(131, 35)
        Me.EmptyCartButton.TabIndex = 41
        Me.EmptyCartButton.Text = "Empty Cart"
        Me.EmptyCartButton.UseVisualStyleBackColor = False
        '
        'SubtotalLabel
        '
        Me.SubtotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.SubtotalLabel.Location = New System.Drawing.Point(586, 656)
        Me.SubtotalLabel.Name = "SubtotalLabel"
        Me.SubtotalLabel.Size = New System.Drawing.Size(100, 23)
        Me.SubtotalLabel.TabIndex = 42
        '
        'TaxLabel
        '
        Me.TaxLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TaxLabel.Location = New System.Drawing.Point(586, 684)
        Me.TaxLabel.Name = "TaxLabel"
        Me.TaxLabel.Size = New System.Drawing.Size(100, 23)
        Me.TaxLabel.TabIndex = 43
        '
        'TotalLabel
        '
        Me.TotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TotalLabel.Location = New System.Drawing.Point(586, 715)
        Me.TotalLabel.Name = "TotalLabel"
        Me.TotalLabel.Size = New System.Drawing.Size(100, 23)
        Me.TotalLabel.TabIndex = 44
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.Final_Project.My.Resources.Resources.Best_Buy_logo
        Me.PictureBox2.Location = New System.Drawing.Point(16, 706)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(180, 82)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 45
        Me.PictureBox2.TabStop = False
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripLabel1, Me.ProductIDToolStripTextBox, Me.SubmitToolStripButton})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 25)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(709, 25)
        Me.ToolStrip1.TabIndex = 47
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ToolStripLabel1
        '
        Me.ToolStripLabel1.Name = "ToolStripLabel1"
        Me.ToolStripLabel1.Size = New System.Drawing.Size(120, 22)
        Me.ToolStripLabel1.Text = "Search by Product ID:"
        '
        'ProductIDToolStripTextBox
        '
        Me.ProductIDToolStripTextBox.Name = "ProductIDToolStripTextBox"
        Me.ProductIDToolStripTextBox.Size = New System.Drawing.Size(100, 25)
        '
        'SubmitToolStripButton
        '
        Me.SubmitToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.SubmitToolStripButton.Image = CType(resources.GetObject("SubmitToolStripButton.Image"), System.Drawing.Image)
        Me.SubmitToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.SubmitToolStripButton.Name = "SubmitToolStripButton"
        Me.SubmitToolStripButton.Size = New System.Drawing.Size(49, 22)
        Me.SubmitToolStripButton.Text = "Submit"
        '
        'PlaceAnOrderForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(709, 805)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.AddToCartButton)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.TotalLabel)
        Me.Controls.Add(Me.TaxLabel)
        Me.Controls.Add(Me.SubtotalLabel)
        Me.Controls.Add(Me.EmptyCartButton)
        Me.Controls.Add(Me.CheckOutButton)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.ShoppingCartListBox)
        Me.Controls.Add(Me.ProductTabControl)
        Me.Controls.Add(Me.MonitorsBindingNavigator)
        Me.Controls.Add(Me.TelevisionsBindingNavigator)
        Me.Controls.Add(Me.ServicesBindingNavigator)
        Me.Controls.Add(Me.ComputersBindingNavigator)
        Me.Controls.Add(Me.ServicesButton)
        Me.Controls.Add(Me.ComputersButton)
        Me.Controls.Add(Me.MonitorsButton)
        Me.Controls.Add(Me.TelevisionsButton)
        Me.Name = "PlaceAnOrderForm"
        Me.Text = "Place An Order"
        CType(Me.CompKCCDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ComputersBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ComputersBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ComputersBindingNavigator.ResumeLayout(False)
        Me.ComputersBindingNavigator.PerformLayout()
        CType(Me.MonitorsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ComputersGroupBox.ResumeLayout(False)
        Me.ComputersGroupBox.PerformLayout()
        Me.MonitorsGroupBox.ResumeLayout(False)
        Me.MonitorsGroupBox.PerformLayout()
        CType(Me.MonitorsBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MonitorsBindingNavigator.ResumeLayout(False)
        Me.MonitorsBindingNavigator.PerformLayout()
        Me.TelevisionsGroupBox.ResumeLayout(False)
        Me.TelevisionsGroupBox.PerformLayout()
        CType(Me.TelevisionsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TelevisionsBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TelevisionsBindingNavigator.ResumeLayout(False)
        Me.TelevisionsBindingNavigator.PerformLayout()
        CType(Me.ServicesBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ServicesBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ServicesBindingNavigator.ResumeLayout(False)
        Me.ServicesBindingNavigator.PerformLayout()
        Me.ProductTabControl.ResumeLayout(False)
        Me.ComputersTabPage.ResumeLayout(False)
        Me.MonitorsTabPage.ResumeLayout(False)
        Me.TelevisionsTabPage.ResumeLayout(False)
        Me.ServicesTabPage.ResumeLayout(False)
        Me.ServicesGroupBox.ResumeLayout(False)
        Me.ServicesGroupBox.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TelevisionsButton As System.Windows.Forms.Button
    Friend WithEvents MonitorsButton As System.Windows.Forms.Button
    Friend WithEvents ComputersButton As System.Windows.Forms.Button
    Friend WithEvents ServicesButton As System.Windows.Forms.Button
    Friend WithEvents CompKCCDataSet As Final_Project.CompKCCDataSet
    Friend WithEvents ComputersBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents ComputersTableAdapter As Final_Project.CompKCCDataSetTableAdapters.ComputersTableAdapter
    Friend WithEvents TableAdapterManager As Final_Project.CompKCCDataSetTableAdapters.TableAdapterManager
    Friend WithEvents ComputersBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ComputersBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents ComputerProductIDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ComputerTypeTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ComputerBrandTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ComputerModelTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ComputerCostTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ComputerDescriptionTextBox As System.Windows.Forms.TextBox
    Friend WithEvents MonitorsBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents MonitorsTableAdapter As Final_Project.CompKCCDataSetTableAdapters.MonitorsTableAdapter
    Friend WithEvents ComputersGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents MonitorProductIDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents MonitorBrandTextBox As System.Windows.Forms.TextBox
    Friend WithEvents MonitorModelTextBox As System.Windows.Forms.TextBox
    Friend WithEvents MonitorTypeTextBox As System.Windows.Forms.TextBox
    Friend WithEvents MonitorSizeTextBox As System.Windows.Forms.TextBox
    Friend WithEvents MonitorCostTextBox As System.Windows.Forms.TextBox
    Friend WithEvents MonitorsGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents MonitorsBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem1 As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem1 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem1 As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem1 As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem1 As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem1 As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem1 As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem1 As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TelevisionsGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents TelevisionsBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TelevisionsTableAdapter As Final_Project.CompKCCDataSetTableAdapters.TelevisionsTableAdapter
    Friend WithEvents TelevisionProductIDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TelevisionTypeTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TelevisionBrandTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TelevisionModelTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TelevisionSizeTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TelevisionCostTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TelevisionsBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem2 As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem2 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem2 As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem2 As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem2 As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem2 As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator7 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem2 As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem2 As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator8 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ServicesBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents ServicesTableAdapter As Final_Project.CompKCCDataSetTableAdapters.ServicesTableAdapter
    Friend WithEvents ServicesBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem3 As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem3 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem3 As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem3 As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem3 As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator9 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem3 As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator10 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem3 As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem3 As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator11 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ProductTabControl As System.Windows.Forms.TabControl
    Friend WithEvents MonitorsTabPage As System.Windows.Forms.TabPage
    Friend WithEvents TelevisionsTabPage As System.Windows.Forms.TabPage
    Friend WithEvents ServicesTabPage As System.Windows.Forms.TabPage
    Friend WithEvents ServicesGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents ServiceProductIDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ServiceTypeTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ServiceModelTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ServiceDescriptionTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ServiceCostTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ComputersTabPage As System.Windows.Forms.TabPage
    Friend WithEvents ShoppingCartListBox As System.Windows.Forms.ListBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents CheckOutButton As System.Windows.Forms.Button
    Friend WithEvents EmptyCartButton As System.Windows.Forms.Button
    Friend WithEvents SubtotalLabel As System.Windows.Forms.Label
    Friend WithEvents TaxLabel As System.Windows.Forms.Label
    Friend WithEvents TotalLabel As System.Windows.Forms.Label
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents AddToCartButton As System.Windows.Forms.Button
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents ToolStripLabel1 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ProductIDToolStripTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents SubmitToolStripButton As System.Windows.Forms.ToolStripButton
End Class
