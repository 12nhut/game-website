﻿'Programmer:        Kevin Kruse
'Date:              11/30/2011
'Project:           Final Project Milestone 2

Public Class ServicesClass
    Private ProductIDString As String
    Private TypeString As String
    Private ModelString As String
    Private DescriptionString As String
    Private CostDecimal As Decimal

    Public Sub New()
        'Empty constructor
    End Sub

    'Full constructor
    Public Sub New(ByVal _ProductIDString As String, ByVal _TypeString As String, _
                   ByVal _ModelString As String, ByVal _CostDecimal As Decimal, _
                   ByVal _DescriptionString As String)
        With Me
            .ProductIDString = _ProductIDString
            .TypeString = _TypeString
            .ModelString = _ModelString
            .CostDecimal = _CostDecimal
            .DescriptionString = _DescriptionString
        End With
    End Sub

    Public Property ProductID As String
        Get
            Return Me.ProductIDString
        End Get
        Set(ByVal value As String)
            Me.ProductIDString = value
        End Set
    End Property

    Public Property Type As String
        Get
            Return Me.TypeString
        End Get
        Set(ByVal value As String)
            Me.TypeString = value
        End Set
    End Property

    Public Property Model As String
        Get
            Return Me.ModelString
        End Get
        Set(ByVal value As String)
            Me.ModelString = value
        End Set
    End Property

    Public Property Description As String
        Get
            Return Me.DescriptionString
        End Get
        Set(ByVal value As String)
            Me.DescriptionString = value
        End Set
    End Property

    Public Property Cost As Decimal
        Get
            Return Me.CostDecimal
        End Get
        Set(ByVal value As Decimal)
            Me.CostDecimal = value
        End Set
    End Property

    Public Overrides Function ToString() As String
        Dim ServicesString As String = "Product ID:" & ProductIDString & ", " & _
                                       "Type: " & TypeString & ", " & _
                                       "Model: " & ModelString & ", " & _
                                       "Cost: " & CostDecimal & ", " & _
                                       "Description: " & DescriptionString & "."

        Return ServicesString

    End Function
End Class
