﻿'Programmers:       Nhuan Thi & Kevin Kruse
'Date:              11/23/2011
'Project:           Final Exam
'Description:
'This class is designed to be a template for each event log item for the Bestbuy application

Public Class EventLogItem
    Public Property LogEntryID() As Integer
    Public Property TimeStamp() As Date
    Public Property Message() As String
    Public Property Severity() As String
End Class
