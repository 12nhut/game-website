﻿'Programmer:        Nhuan Thi
'Date:              11/30/2011
'Project:           Final Project Milestone 2

Public Class AllProductReturnsForm

    Private Sub ProductReturnsBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ProductReturnsBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.ProductReturnsBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.CompKCCDataSet)

    End Sub

    Private Sub ProductReturnsForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'CompKCCDataSet.ProductReturns' table. You can move, or remove it, as needed.
        Me.ProductReturnsTableAdapter.Fill(Me.CompKCCDataSet.ProductReturns)

    End Sub

    Private Sub ExitButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Close()
    End Sub

    Private Sub SubmitToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SubmitToolStripButton.Click
        Dim ReturnIDInteger As Integer = ReturnIDToolStripTextBox.Text
        Me.ProductReturnsTableAdapter.FillByProductReturnsReturnID(Me.CompKCCDataSet.ProductReturns, ReturnIDInteger)
    End Sub

    Private Sub ViewReportButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ViewReportButton.Click
        AllProductReturnsReportForm.Show()
    End Sub

    Private Sub ProductReturnsDataGridView_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles ProductReturnsDataGridView.CellContentClick
        If e.ColumnIndex = 6 Then
            Dim RowInteger As Integer = e.RowIndex
            Dim Row As DataGridViewRow = ProductReturnsDataGridView.Rows(RowInteger)
            Dim Cell As DataGridViewCell = Row.Cells(0)

            Dim EmployeeIDInteger As Integer = CInt(Cell.Value)
            Dim NewAllEmployeeForm As New AllEmployeesForm
            NewAllEmployeeForm.Tag = EmployeeIDInteger
            NewAllEmployeeForm.Show()
        End If
    End Sub
End Class