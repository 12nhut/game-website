﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ProductReturnsForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ReturnIDLabel As System.Windows.Forms.Label
        Dim EmployeeIDLabel As System.Windows.Forms.Label
        Dim ProductIDLabel As System.Windows.Forms.Label
        Dim QuantityLabel As System.Windows.Forms.Label
        Dim DateReturnedLabel As System.Windows.Forms.Label
        Dim ReasonLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ProductReturnsForm))
        Me.CompKCCDataSet = New Final_Project.CompKCCDataSet()
        Me.ProductReturnsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ProductReturnsTableAdapter = New Final_Project.CompKCCDataSetTableAdapters.ProductReturnsTableAdapter()
        Me.TableAdapterManager = New Final_Project.CompKCCDataSetTableAdapters.TableAdapterManager()
        Me.ProductReturnsBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ProductReturnsBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.ReturnIDTextBox = New System.Windows.Forms.TextBox()
        Me.EmployeeIDTextBox = New System.Windows.Forms.TextBox()
        Me.ProductIDTextBox = New System.Windows.Forms.TextBox()
        Me.QuantityTextBox = New System.Windows.Forms.TextBox()
        Me.DateReturnedDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.ReasonTextBox = New System.Windows.Forms.TextBox()
        Me.ViewEmployeesButton = New System.Windows.Forms.Button()
        Me.ClearButton = New System.Windows.Forms.Button()
        ReturnIDLabel = New System.Windows.Forms.Label()
        EmployeeIDLabel = New System.Windows.Forms.Label()
        ProductIDLabel = New System.Windows.Forms.Label()
        QuantityLabel = New System.Windows.Forms.Label()
        DateReturnedLabel = New System.Windows.Forms.Label()
        ReasonLabel = New System.Windows.Forms.Label()
        CType(Me.CompKCCDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ProductReturnsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ProductReturnsBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ProductReturnsBindingNavigator.SuspendLayout()
        Me.SuspendLayout()
        '
        'ReturnIDLabel
        '
        ReturnIDLabel.AutoSize = True
        ReturnIDLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        ReturnIDLabel.Location = New System.Drawing.Point(12, 59)
        ReturnIDLabel.Name = "ReturnIDLabel"
        ReturnIDLabel.Size = New System.Drawing.Size(83, 20)
        ReturnIDLabel.TabIndex = 1
        ReturnIDLabel.Text = "Return ID:"
        '
        'EmployeeIDLabel
        '
        EmployeeIDLabel.AutoSize = True
        EmployeeIDLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        EmployeeIDLabel.Location = New System.Drawing.Point(12, 93)
        EmployeeIDLabel.Name = "EmployeeIDLabel"
        EmployeeIDLabel.Size = New System.Drawing.Size(104, 20)
        EmployeeIDLabel.TabIndex = 3
        EmployeeIDLabel.Text = "Employee ID:"
        '
        'ProductIDLabel
        '
        ProductIDLabel.AutoSize = True
        ProductIDLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        ProductIDLabel.Location = New System.Drawing.Point(12, 127)
        ProductIDLabel.Name = "ProductIDLabel"
        ProductIDLabel.Size = New System.Drawing.Size(89, 20)
        ProductIDLabel.TabIndex = 5
        ProductIDLabel.Text = "Product ID:"
        '
        'QuantityLabel
        '
        QuantityLabel.AutoSize = True
        QuantityLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        QuantityLabel.Location = New System.Drawing.Point(12, 161)
        QuantityLabel.Name = "QuantityLabel"
        QuantityLabel.Size = New System.Drawing.Size(72, 20)
        QuantityLabel.TabIndex = 7
        QuantityLabel.Text = "Quantity:"
        '
        'DateReturnedLabel
        '
        DateReturnedLabel.AutoSize = True
        DateReturnedLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DateReturnedLabel.Location = New System.Drawing.Point(12, 195)
        DateReturnedLabel.Name = "DateReturnedLabel"
        DateReturnedLabel.Size = New System.Drawing.Size(119, 20)
        DateReturnedLabel.TabIndex = 9
        DateReturnedLabel.Text = "Date Returned:"
        '
        'ReasonLabel
        '
        ReasonLabel.AutoSize = True
        ReasonLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        ReasonLabel.Location = New System.Drawing.Point(12, 229)
        ReasonLabel.Name = "ReasonLabel"
        ReasonLabel.Size = New System.Drawing.Size(69, 20)
        ReasonLabel.TabIndex = 11
        ReasonLabel.Text = "Reason:"
        '
        'CompKCCDataSet
        '
        Me.CompKCCDataSet.DataSetName = "CompKCCDataSet"
        Me.CompKCCDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ProductReturnsBindingSource
        '
        Me.ProductReturnsBindingSource.DataMember = "ProductReturns"
        Me.ProductReturnsBindingSource.DataSource = Me.CompKCCDataSet
        '
        'ProductReturnsTableAdapter
        '
        Me.ProductReturnsTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.ComputersTableAdapter = Nothing
        Me.TableAdapterManager.CustomerOrdersTableAdapter = Nothing
        Me.TableAdapterManager.CustomersTableAdapter = Nothing
        Me.TableAdapterManager.EmployeesTableAdapter = Nothing
        Me.TableAdapterManager.InvoicesTableAdapter = Nothing
        Me.TableAdapterManager.LocationsTableAdapter = Nothing
        Me.TableAdapterManager.MonitorsTableAdapter = Nothing
        Me.TableAdapterManager.ProductReturnsTableAdapter = Me.ProductReturnsTableAdapter
        Me.TableAdapterManager.ServicesTableAdapter = Nothing
        Me.TableAdapterManager.TelevisionsTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = Final_Project.CompKCCDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'ProductReturnsBindingNavigator
        '
        Me.ProductReturnsBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.ProductReturnsBindingNavigator.BindingSource = Me.ProductReturnsBindingSource
        Me.ProductReturnsBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.ProductReturnsBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.ProductReturnsBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.ProductReturnsBindingNavigatorSaveItem})
        Me.ProductReturnsBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.ProductReturnsBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.ProductReturnsBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.ProductReturnsBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.ProductReturnsBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.ProductReturnsBindingNavigator.Name = "ProductReturnsBindingNavigator"
        Me.ProductReturnsBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.ProductReturnsBindingNavigator.Size = New System.Drawing.Size(563, 25)
        Me.ProductReturnsBindingNavigator.TabIndex = 0
        Me.ProductReturnsBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'ProductReturnsBindingNavigatorSaveItem
        '
        Me.ProductReturnsBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ProductReturnsBindingNavigatorSaveItem.Image = CType(resources.GetObject("ProductReturnsBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.ProductReturnsBindingNavigatorSaveItem.Name = "ProductReturnsBindingNavigatorSaveItem"
        Me.ProductReturnsBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.ProductReturnsBindingNavigatorSaveItem.Text = "Save Data"
        '
        'ReturnIDTextBox
        '
        Me.ReturnIDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ProductReturnsBindingSource, "ReturnID", True))
        Me.ReturnIDTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ReturnIDTextBox.Location = New System.Drawing.Point(141, 53)
        Me.ReturnIDTextBox.Name = "ReturnIDTextBox"
        Me.ReturnIDTextBox.Size = New System.Drawing.Size(61, 26)
        Me.ReturnIDTextBox.TabIndex = 2
        '
        'EmployeeIDTextBox
        '
        Me.EmployeeIDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ProductReturnsBindingSource, "EmployeeID", True))
        Me.EmployeeIDTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EmployeeIDTextBox.Location = New System.Drawing.Point(141, 90)
        Me.EmployeeIDTextBox.Name = "EmployeeIDTextBox"
        Me.EmployeeIDTextBox.Size = New System.Drawing.Size(61, 26)
        Me.EmployeeIDTextBox.TabIndex = 4
        '
        'ProductIDTextBox
        '
        Me.ProductIDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ProductReturnsBindingSource, "ProductID", True))
        Me.ProductIDTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ProductIDTextBox.Location = New System.Drawing.Point(141, 124)
        Me.ProductIDTextBox.Name = "ProductIDTextBox"
        Me.ProductIDTextBox.Size = New System.Drawing.Size(61, 26)
        Me.ProductIDTextBox.TabIndex = 6
        '
        'QuantityTextBox
        '
        Me.QuantityTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ProductReturnsBindingSource, "Quantity", True))
        Me.QuantityTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.QuantityTextBox.Location = New System.Drawing.Point(141, 158)
        Me.QuantityTextBox.Name = "QuantityTextBox"
        Me.QuantityTextBox.Size = New System.Drawing.Size(61, 26)
        Me.QuantityTextBox.TabIndex = 8
        '
        'DateReturnedDateTimePicker
        '
        Me.DateReturnedDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.ProductReturnsBindingSource, "DateReturned", True))
        Me.DateReturnedDateTimePicker.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DateReturnedDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DateReturnedDateTimePicker.Location = New System.Drawing.Point(141, 194)
        Me.DateReturnedDateTimePicker.Name = "DateReturnedDateTimePicker"
        Me.DateReturnedDateTimePicker.Size = New System.Drawing.Size(133, 26)
        Me.DateReturnedDateTimePicker.TabIndex = 10
        '
        'ReasonTextBox
        '
        Me.ReasonTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ProductReturnsBindingSource, "Reason", True))
        Me.ReasonTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ReasonTextBox.Location = New System.Drawing.Point(141, 226)
        Me.ReasonTextBox.Name = "ReasonTextBox"
        Me.ReasonTextBox.Size = New System.Drawing.Size(410, 26)
        Me.ReasonTextBox.TabIndex = 12
        '
        'ViewEmployeesButton
        '
        Me.ViewEmployeesButton.BackColor = System.Drawing.Color.Blue
        Me.ViewEmployeesButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ViewEmployeesButton.ForeColor = System.Drawing.Color.White
        Me.ViewEmployeesButton.Location = New System.Drawing.Point(98, 269)
        Me.ViewEmployeesButton.Name = "ViewEmployeesButton"
        Me.ViewEmployeesButton.Size = New System.Drawing.Size(186, 57)
        Me.ViewEmployeesButton.TabIndex = 13
        Me.ViewEmployeesButton.Text = "View Employees"
        Me.ViewEmployeesButton.UseVisualStyleBackColor = False
        '
        'ClearButton
        '
        Me.ClearButton.BackColor = System.Drawing.Color.Blue
        Me.ClearButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ClearButton.ForeColor = System.Drawing.Color.White
        Me.ClearButton.Location = New System.Drawing.Point(320, 269)
        Me.ClearButton.Name = "ClearButton"
        Me.ClearButton.Size = New System.Drawing.Size(119, 57)
        Me.ClearButton.TabIndex = 14
        Me.ClearButton.Text = "C&lear"
        Me.ClearButton.UseVisualStyleBackColor = False
        '
        'ProductReturnsForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(563, 336)
        Me.Controls.Add(Me.ClearButton)
        Me.Controls.Add(Me.ViewEmployeesButton)
        Me.Controls.Add(ReturnIDLabel)
        Me.Controls.Add(Me.ReturnIDTextBox)
        Me.Controls.Add(EmployeeIDLabel)
        Me.Controls.Add(Me.EmployeeIDTextBox)
        Me.Controls.Add(ProductIDLabel)
        Me.Controls.Add(Me.ProductIDTextBox)
        Me.Controls.Add(QuantityLabel)
        Me.Controls.Add(Me.QuantityTextBox)
        Me.Controls.Add(DateReturnedLabel)
        Me.Controls.Add(Me.DateReturnedDateTimePicker)
        Me.Controls.Add(ReasonLabel)
        Me.Controls.Add(Me.ReasonTextBox)
        Me.Controls.Add(Me.ProductReturnsBindingNavigator)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "ProductReturnsForm"
        Me.Text = "Product Returns"
        CType(Me.CompKCCDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ProductReturnsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ProductReturnsBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ProductReturnsBindingNavigator.ResumeLayout(False)
        Me.ProductReturnsBindingNavigator.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents CompKCCDataSet As Final_Project.CompKCCDataSet
    Friend WithEvents ProductReturnsBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents ProductReturnsTableAdapter As Final_Project.CompKCCDataSetTableAdapters.ProductReturnsTableAdapter
    Friend WithEvents TableAdapterManager As Final_Project.CompKCCDataSetTableAdapters.TableAdapterManager
    Friend WithEvents ProductReturnsBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ProductReturnsBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents ReturnIDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents EmployeeIDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ProductIDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents QuantityTextBox As System.Windows.Forms.TextBox
    Friend WithEvents DateReturnedDateTimePicker As System.Windows.Forms.DateTimePicker
    Friend WithEvents ReasonTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ViewEmployeesButton As System.Windows.Forms.Button
    Friend WithEvents ClearButton As System.Windows.Forms.Button
End Class
