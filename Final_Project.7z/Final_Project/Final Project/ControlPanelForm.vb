﻿'Programmer:        Kevin Kruse
'Date:              11/30/2011
'Project:           Final Project Milestone 2

Public Class ControlPanelForm

    Private Sub PlaceOrderButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PlaceOrderButton.Click
        'Creates a new place an order form and displays it in the parent form
        Dim NewPlaceAnOrderForm As New PlaceAnOrderForm
        NewPlaceAnOrderForm.MdiParent = MainForm
        NewPlaceAnOrderForm.Show()
    End Sub

    Private Sub LocationsButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LocationsButton.Click
        'Creates a new locations form and displays it in the parent form
        Dim NewLocationsForm As New LocationsForm
        NewLocationsForm.MdiParent = MainForm
        NewLocationsForm.Show()
    End Sub

    Private Sub EmployeesButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EmployeesButton.Click
        'Creates a new employees form and displays it in the parent form
        Dim NewEmployeesForm As New AllEmployeesForm
        NewEmployeesForm.MdiParent = MainForm
        NewEmployeesForm.Show()
    End Sub

    Private Sub ControlPanelForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub ViewOrdersButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ViewOrdersButton.Click
        'Creates a NewCustomerOrdersForm form and displays it in the parent form
        Dim NewCustomerOrdersForm As New CustomerOrdersForm
        NewCustomerOrdersForm.MdiParent = MainForm
        NewCustomerOrdersForm.Show()
    End Sub

    Private Sub CustomersButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CustomersButton.Click
        'Creates a NewAllCustomersForm form and displays it in the parent form
        Dim NewAllCustomersForm As New AllCustomersForm
        NewAllCustomersForm.MdiParent = MainForm
        NewAllCustomersForm.Show()
    End Sub

    Private Sub ReturnsButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReturnsButton.Click
        'Creates a new All Product Returns form and displays it in the parent form
        Dim NewAllProductReturnsForm As New AllProductReturnsForm
        NewAllProductReturnsForm.MdiParent = MainForm
        NewAllProductReturnsForm.Show()
    End Sub
End Class