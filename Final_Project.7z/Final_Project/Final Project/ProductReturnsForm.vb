﻿'Programmer:        Nhuan Thi
'Date:              11/30/2011
'Project:           Final Project Milestone 2

Public Class ProductReturnsForm

    Private Sub ProductReturnsBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ProductReturnsBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.ProductReturnsBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.CompKCCDataSet)

    End Sub

    Private Sub ProductReturnsForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'CompKCCDataSet.ProductReturns' table. You can move, or remove it, as needed.
        Me.ProductReturnsTableAdapter.Fill(Me.CompKCCDataSet.ProductReturns)

    End Sub

    Private Sub ExitButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearButton.Click
        Me.Close()
    End Sub

    Private Sub ViewEmployeesButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ViewEmployeesButton.Click

    End Sub
End Class