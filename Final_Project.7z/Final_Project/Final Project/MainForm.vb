﻿Option Strict On
Imports System.IO
'Programmer:        Kevin Kruse
'Date:              11/30/2011
'Project:           Final Project Milestone 2
'Description:
'This is the MDI Parent for this application.  This form acts as a hub to all other forms.
'This form manages the event logging procedures 
Public Class MainForm

    Private EventLogFilePathString As String = My.Application.Info.DirectoryPath & "\..\..\EventLog.xml"
    Private EventLogXDocument As XDocument
    Public LoggedInEmployee As Integer

    Private Sub MainForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Event Log - Logs that the application has successfully STARTED
        Dim EventMessageString As String = "Application has successfully started."
        Dim SeverityLevelString As String = "Low"
        EventMessageLog(EventMessageString, SeverityLevelString)

        'Creates and displays the Login form in Modal
        Dim NewLoginForm As New LoginForm
        NewLoginForm.ShowDialog()
    End Sub

    Private Sub MainForm_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        'Event Log - Logs that the application has successfully CLOSED
        Dim EventMessageString As String = "Application has been closed."
        Dim SeverityLevelString As String = "Low"
        EventMessageLog(EventMessageString, SeverityLevelString)
    End Sub

    Public Sub EventMessageLog(ByVal EventMessageString As String, ByVal SeverityLevelString As String)
        'Checks to see if the event log xml database exists
        'if exists load into xdocument otherwise display error message
        If File.Exists(EventLogFilePathString) Then
            EventLogXDocument = XDocument.Load(EventLogFilePathString)
        Else
            MessageBox.Show("Event log database file doesn't exist")
            Exit Sub
        End If

        'LINQ query to determine the last log entry ID attribute
        Dim MaxEventsID = Aggregate SingleEvent In EventLogXDocument...<LogEntry> _
                          Into Max(SingleEvent.@ID)

        'Create new event log item and add it to the list
        Dim NewEvent As New EventLogItem
        Dim ThisDate As Date = CDate(FormatDateTime(Date.Now(), DateFormat.GeneralDate))
        NewEvent.LogEntryID = CInt(MaxEventsID) + 1
        NewEvent.TimeStamp = ThisDate
        NewEvent.Message = EventMessageString
        NewEvent.Severity = SeverityLevelString

        Dim NewEventXElement As XElement = New XElement("LogEntry")
        With NewEventXElement
            .Add(New XAttribute("ID", NewEvent.LogEntryID))
            .Add(New XElement("TimeStamp", NewEvent.TimeStamp))
            .Add(New XElement("Message", NewEvent.Message))
            .Add(New XElement("Severity", NewEvent.Severity))
        End With
        'Put the new XElement into the root of the XML file
        EventLogXDocument.Root.Add(NewEventXElement)
        EventLogXDocument.Save(EventLogFilePathString)
    End Sub

    Private Sub ExitApplicationToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitApplicationToolStripMenuItem.Click
        'Closes this application
        Application.Exit()
    End Sub

    Private Sub LoadControlPanelToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LoadControlPanelToolStripMenuItem.Click
        'Create control panel form and load the control panel
        'Create a new CustomerMaintenance Form, then show it
        Dim NewControlPanelForm As New ControlPanelForm
        NewControlPanelForm.MdiParent = Me
        NewControlPanelForm.Show()
    End Sub

    Private Sub AboutToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AboutToolStripMenuItem.Click
            Dim NewBestBuyAboutBox As New BestBuyAboutBox
            NewBestBuyAboutBox.Show()
    End Sub
End Class
