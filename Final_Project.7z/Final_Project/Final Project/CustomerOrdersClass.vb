﻿'Class for CustomerOrders table
'Programmer:        Nhuan Thi
'Date:              11/30/2011
'Project:           Final Project Milestone 2
Public Class CustomerOrdersClass
    'Variables
    Private OrderIDInteger As Integer
    Private CustomerIDInteger As Integer
    Private ProductIDString As String
    Private InvoiceDateDate As Date
    Private CostDecimal As Decimal
    Private QuantityInteger As Integer
    Private SubtotalDecimal As Decimal
    Private TaxDecimal As Decimal
    Private TotalDecimal As Decimal
    'Empty constructor
    Public Sub New()

    End Sub
    'Full constructor with all variables
    Public Sub New(ByVal _OrderIDInteger As Integer, ByVal _CustomerIDInteger As Integer, ByVal _ProductIDString As String, _
                   ByVal _DateDate As Date, ByVal _CostDecimal As Decimal, ByVal _QuantityInteger As Integer, _
                   ByVal _SubtotalDecimal As Decimal, ByVal _TaxDecimal As Decimal, ByVal _TotalDecimal As Decimal)
        With Me
            .OrderIDInteger = _OrderIDInteger
            .CustomerIDInteger = _CustomerIDInteger
            .ProductIDString = _ProductIDString
            .InvoiceDateDate = _DateDate
            .CostDecimal = _CostDecimal
            .QuantityInteger = _QuantityInteger
            .SubtotalDecimal = _SubtotalDecimal
            .TaxDecimal = _TaxDecimal
            .TotalDecimal = _TotalDecimal
        End With
    End Sub
    'Methods
    Public ReadOnly Property OrderID() As Integer
        Get
            Return Me.OrderIDInteger
        End Get
    End Property

    Public ReadOnly Property CustomerID() As Integer
        Get
            Return Me.CustomerIDInteger
        End Get
    End Property

    Public ReadOnly Property ProductID() As String
        Get
            Return Me.ProductIDString
        End Get
    End Property

    Public Property InvoiceDate() As Date
        Get
            Return Me.InvoiceDateDate
        End Get
        Set(ByVal value As Date)
            Me.InvoiceDateDate = value
        End Set
    End Property

    Public Property Cost() As Decimal
        Get
            Return Me.CostDecimal
        End Get
        Set(ByVal value As Decimal)
            Me.CostDecimal = value
        End Set
    End Property

    Public Property Quantity() As Integer
        Get
            Return Me.QuantityInteger
        End Get
        Set(ByVal value As Integer)
            Me.QuantityInteger = value
        End Set
    End Property

    Public Property Subtotal() As Decimal
        Get
            Return Me.SubtotalDecimal
        End Get
        Set(ByVal value As Decimal)
            Me.SubtotalDecimal = value
        End Set
    End Property

    Public Property Tax() As Decimal
        Get
            Return Me.TaxDecimal
        End Get
        Set(ByVal value As Decimal)
            Me.TaxDecimal = value
        End Set
    End Property

    Public Property Total() As Decimal
        Get
            Return Me.TotalDecimal
        End Get
        Set(ByVal value As Decimal)
            Me.TotalDecimal = value
        End Set
    End Property
    'ToString function
    Public Overrides Function ToString() As String
        Dim InvoiceInfoString As String = "Order ID: " & Me.OrderIDInteger & "," & _
                                            "Customer ID: " & Me.CustomerIDInteger & "," & _
                                            "Product ID: " & Me.ProductIDString & "," & _
                                            "Date: " & Me.InvoiceDateDate & "," &
                                            "Cost: " & Me.CostDecimal & "," & _
                                            "Quantity: " & Me.QuantityInteger & "," & _
                                            "Subtotal: " & Me.SubtotalDecimal & "," & _
                                            "Tax: " & Me.TaxDecimal & "," & _
                                            "Total: " & Me.TotalDecimal & "."
        Return InvoiceInfoString
    End Function
End Class
