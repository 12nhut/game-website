﻿'Programmer:        Kevin Kruse
'Date:              11/30/2011
'Project:           Final Project Milestone 3

Public Class AllEmployeesForm

    Private Sub EmployeesBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Validate()
        Me.EmployeesBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.CompKCCDataSet)
    End Sub

    Private Sub EmployeesForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'if this form's tag is empty
        If Me.Tag Is Nothing Then
            'fill the form with original data
            Me.EmployeesTableAdapter.Fill(Me.CompKCCDataSet.Employees)
        Else
            'else retrieve the EmployeeID from the tag
            Dim EmployeeIDInteger As Integer = Me.Tag
            'fill the form by the EmployeeID
            Me.EmployeesTableAdapter.FillByEmployeeID(Me.CompKCCDataSet.Employees, EmployeeIDInteger)
        End If
    End Sub

    Private Sub EmployeesDataGridView_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles EmployeesDataGridView.CellContentClick
        'retrieve the row and cell that populate the value
        Dim RowInteger As Integer = e.RowIndex
        Dim Row As DataGridViewRow = EmployeesDataGridView.Rows(RowInteger)
        Dim Cell As DataGridViewCell = Row.Cells(0)
        'retrieve the CustomerID
        Dim EmployeeIDInteger As Integer = CInt(Cell.Value)

        'if OrderMade datagridview button is clicked
        If e.ColumnIndex = 3 Then
            'create a new CustomerOrdersForm
            Dim NewCustomerOrdersForm As New CustomerOrdersForm
            'put the EmployeeID to CustomerOrdersForm's tag
            NewCustomerOrdersForm.Tag = EmployeeIDInteger
            'show the CustomerOrdersForm
            NewCustomerOrdersForm.Show()
            'if ReturnsMade datagridview button is clicked
        ElseIf e.ColumnIndex = 4 Then
            'create a new ProductReturnsForm
            Dim NewProductReturnsForm As New ProductReturnsForm
            ''put the EmployeeID to PrdocutReturnsForm's tag
            NewProductReturnsForm.Tag = EmployeeIDInteger
            'show the ProductReturnsForm
            NewProductReturnsForm.Show()
        End If
    End Sub
End Class