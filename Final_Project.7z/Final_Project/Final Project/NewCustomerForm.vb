﻿
Public Class NewCustomerForm

    Private Sub NewCustomerForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'CompKCCDataSet.Customers' table. You can move, or remove it, as needed.
        Me.CustomersTableAdapter.Fill(Me.CompKCCDataSet.Customers)

    End Sub
    Private Sub CreateButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CreateButton.Click

        'LINQ query to pull out all of the CustomerID's
        Dim AllCustomerID = From SingleCustomer As CompKCCDataSet.CustomersRow In CompKCCDataSet.Customers.Rows
                             Select SingleCustomer.CustomerID

        'Gets the MAX value(last customer) and adds 1 for the new customer ID
        Dim NewCustomerIDInteger As Integer = AllCustomerID.Max + 1

        'Creates a new customer object and adds it to the list of customers
        Dim NewCustomer As Customer = New Customer(NewCustomerIDInteger, FullNameTextBox.Text, AddressTextBox.Text, _
                CityTextBox.Text, StateTextBox.Text, ZipCodeTextBox.Text)

        'Add the new customer to the Tag to be retrieved by the OrderConfirmation Form when this form closes
        Me.Tag = NewCustomer
        Me.Close()
    End Sub

    Private Sub CancelButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CancelNewCustomerButton.Click
        Me.Close()
    End Sub

    Private Sub ClearButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearButton.Click
        FullNameTextBox.Clear()
        AddressTextBox.Clear()
        CityTextBox.Clear()
        StateTextBox.Clear()
        ZipCodeTextBox.Clear()
    End Sub

End Class