﻿'Class for the Customers table
'Programmer:        Nhuan Thi
'Date:              11/30/2011
'Project:           Final Project Milestone 2
Public Class Customer
    'Variables
    Private CustomerIDInteger As Integer
    Private FullNameString As String
    Private AddressString As String
    Private CityString As String
    Private StateString As String
    Private ZipCodeString As String
    'Empty constuctor
    Public Sub New()

    End Sub
    'Full constructor with all variables
    Public Sub New(ByVal _CustomerIDInteger As Integer, ByVal _FullNameString As String, _
                   ByVal _AddressString As String, ByVal _CityString As String, ByVal _StateString As String, _
                   ByVal _ZipCodeString As String)
        With Me
            .CustomerIDInteger = _CustomerIDInteger
            .FullNameString = _FullNameString
            .AddressString = _AddressString
            .CityString = _CityString
            .StateString = _StateString
            .ZipCodeString = _ZipCodeString
        End With
    End Sub
    'Methods
    Public ReadOnly Property CustomerID() As Integer
        Get
            Return Me.CustomerIDInteger
        End Get
    End Property

    Public Property FullName() As String
        Get
            Return Me.FullNameString
        End Get
        Set(ByVal value As String)
            Me.FullNameString = value
        End Set
    End Property

    Public Property Address() As String
        Get
            Return Me.AddressString
        End Get
        Set(ByVal value As String)
            Me.AddressString = value
        End Set
    End Property

    Public Property City() As String
        Get
            Return Me.CityString
        End Get
        Set(ByVal value As String)
            Me.CityString = value
        End Set
    End Property

    Public Property State() As String
        Get
            Return Me.StateString
        End Get
        Set(ByVal value As String)
            Me.StateString = value
        End Set
    End Property

    Public Property ZipCode() As String
        Get
            Return Me.ZipCodeString
        End Get
        Set(ByVal value As String)
            Me.ZipCodeString = value
        End Set
    End Property
    'ToString function
    Public Overrides Function ToString() As String
        Dim CustomerInfoString As String = "Customer ID: " & Me.CustomerIDInteger & "," & _
                                            "First name: " & Me.FullNameString & "," & _
                                            "Address: " & Me.AddressString & "," & _
                                            "City: " & Me.CityString & "," & _
                                            "State: " & Me.StateString & "," & _
                                            "ZipCode: " & Me.ZipCodeString & "."
        Return CustomerInfoString
    End Function
End Class
