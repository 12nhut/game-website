﻿'Programmer:        Kevin Kruse
'Date:              11/30/2011
'Project:           Final Project Milestone 2

Public Class InvoicesClass
    Private OrderIDInteger As Integer
    Private ProductIDInteger As Integer

    Public Sub New()
        'Empty constructor
    End Sub

    'Full constructor
    Public Sub New(ByVal _OrderIDInteger As Integer, ByVal _ProductIDInteger As Integer)
        With Me
            .OrderIDInteger = _OrderIDInteger
            .ProductIDInteger = _ProductIDInteger

        End With
    End Sub

    Public ReadOnly Property OrderID As Integer
        Get
            Return Me.OrderIDInteger
        End Get
    End Property

    Public ReadOnly Property ProductID As Integer
        Get
            Return Me.ProductIDInteger
        End Get

    End Property


    Public Overrides Function ToString() As String
        Dim InvoicesString As String = "Order ID: " & OrderIDInteger & _
                                       "Product ID: " & ProductIDInteger & ".'"
        Return InvoicesString
    End Function
End Class
