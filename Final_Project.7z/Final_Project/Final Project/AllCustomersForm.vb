﻿'Programmer:        Nhuan Thi
'Date:              11/30/2011
'Project:           Final Project Milestone 2

Public Class AllCustomersForm

    Private Sub CustomersBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CustomersBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.CustomersBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.CompKCCDataSet)
    End Sub

    Private Sub CustomersForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'if this form's tag is empty
        If Me.Tag Is Nothing Then
            'fill the form with the original data
            Me.CustomersTableAdapter.Fill(Me.CompKCCDataSet.Customers)
        Else
            'else retrieve the CustomerID from the tag
            Dim CustomerIDInteger As Integer = Me.Tag
            'fill the form by the CustomerID
            Me.CustomersTableAdapter.FillByCustomerID(Me.CompKCCDataSet.Customers, CustomerIDInteger)
        End If
    End Sub

    Private Sub ViewInvoicesButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ViewInvoicesButton.Click
        'Retrieve the Customer ID value from textbox
        Dim CustomerIDInteger As Integer = CustomerIDTextBox.Text
        'create a new CustomerOrdersForm object
        Dim NewCustomerOrdersForm As New CustomerOrdersForm
        'put the CustomerID variable into the CustomerOrderForm's tag
        NewCustomerOrdersForm.Tag = CustomerIDInteger
        'Show the CustomerOrders form
        NewCustomerOrdersForm.Show()
    End Sub

    Private Sub SearchToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SearchToolStripButton.Click
        'retrieve the CustomerName from the toolstrip textbox
        Dim CustomerNameString As String = FullNameToolStripTextBox.Text
        'fill the form by the CustomerName entered
        Me.CustomersTableAdapter.FillByFullName(Me.CompKCCDataSet.Customers, CustomerNameString)
    End Sub
End Class